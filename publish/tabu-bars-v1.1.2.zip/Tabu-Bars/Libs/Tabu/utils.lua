local A = Tabu:Addon(...);
local _ = A.utils;

_.print = function(...)
	print("|cffff8000"..A.Name.."|r", ...);
end



local currentId = 0;
local setUniqueId = function(id, shouldNotCache)
	currentId = id;
	if (not shouldNotCache) then
		local cache = A:GetCache();
		cache.uniqueidentifier = id;
	end
end

_.initializeUniqueId = function()
	local cache = A:GetCache();
	setUniqueId(cache.uniqueidentifier or 0, true);
end


_.updateUniqueId = function(item)
	if (item and item.rawId > currentId) then
		currentId = id;
	end
end

_.uniqueId = function(prefix)
	local newid = currentId + 1;

	setUniqueId(newid);

	if (prefix) then
		newid = prefix..newid;
	end
	return newid;
end

_.setId = function(item, prefix)
	item.rawId = _.uniqueId();
	if (prefix) then
		item.id = prefix .. item.rawId;
	else
		item.id = item.rawId;
	end
end




local spellLinkTemplate = "|cff71d5ff|Hspell:%s|h[%s]|h|r";
_.GetSpellLink = function(name)
	local sname, __, __, __, __, __, sid = GetSpellInfo(name);

	return string.format(spellLinkTemplate, sid, sname);
end



_.GetRankedSpellName = function(spell, rank)
	if (type(rank) ~= "number") then
		error("Wrong argument type. rank must be a number");
	end
	if (not _.isValue(spell)) then return end
	if (not _.isValue(rank)) then return spell end
	local rankWord = _.GetSpellRankWord();
	if (not rankWord) then return spell; end
	return rankWord:GetName(spell, rank);

end


_.GetRankedSpellInfo = function(id, name)
	if (not id) then return name end
	local s, rankedName, rankSpell, currentName, currentRank, maxRank;
	
	local index = 1;
	local stop = false;

	while (not stop) do
		rankedName = _.GetRankedSpellName(name, index);
		if (rankedName == name) then
			return name;
		end
		rankSpell, s, s, s, s, s, rankId  = GetSpellInfo(rankedName);
		if (not rankSpell) then
			if (index == 1) then
				return name;
			end
			stop = true;
			break;
		end
		if (id == rankId) then
			currentName = rankedName
			currentRank = index;
		end
		index = index + 1;
	end
	maxRank = index - 1;
	return currentName, currentRank, maxRank, currentRank == maxRank
end



_.GetSpellInfoTable = function(arg)
	local byId = type(arg) == "number";

	-- if (byId and Tabu.spellCache[arg]) then
	-- 	return _.cloneTable(Tabu.spellCache[arg], false);
	-- end

	local name, rank, icon, castTime, minRange, maxRange, id = GetSpellInfo(arg);
	
	if (not name or not id) then return end

	local tbl = {  
		id = id,
		name = name,
		fullName = name,
		rank = rank,
		icon = icon,
		castTime = castTime,
		minRange = minRange,
		maxRange = maxRange,
		link = _.GetSpellLink(id)
	}
	
	local fullName, spellRank, maxRank, isMaxRank = _.GetRankedSpellInfo(id, name);

	tbl.fullName = fullName;
	tbl.spellRank = spellRank;
	tbl.maxRank = maxRank;
	tbl.isMaxRank = isMaxRank;

	return tbl;
end

_.GetItemInfoTable = function(id)
	local arg = id;
	local name, link, rarity, level, minLevel, itemType, subType, stackCount, equipLoc, icon, sellPrice = GetItemInfo(id);
	if (type(id) ~= "number" and name) then
		id = GetItemInfoInstant(name);
	end
	local res = {
		id = id,
		name = name, 		
		link = link, 
		rarity = rarity, 
		level = level, 
		minLevel = minLevel, 
		type = itemType, 
		subType = subType, 
		stackCount = stackCount, 
		equipLoc = equipLoc, 
		icon = icon, 
		sellPrice = sellPrice
	}
	return res;
end

_.GetMacroInfoTable = function (id)
	local name, icon, body, isLocal = GetMacroInfo(id)
	return {
		id = id,
		name = name,
		icon = icon,
		body,
		isLocal = isLocal
	}
end

_.buildFrameName = function(frameName)
	return A.Name .. "_" .. frameName;
end


local function GetSpellbookItemRankWord(index, book)
	local word;

	local spellName, rankName, spellId = GetSpellBookItemName(index, book);
	if (not spellName) then return nil, false end

	if (not _.isValue(rankName)) then return nil, true end;

	word = string.gsub(rankName, "%d+", "");
	if (not word) then return nil, true end
	rank = string.gsub(rankName, "%D", "");
	if (not _.isValue(rank)) then return nil, true end;

	local checkName = spellName.."("..word.." "..rank..")";
	local tested = GetSpellInfo(checkName);
	if (tested) then
		return word;
	else
		checkName = spellName.."("..rank.." "..word..")";
		tested = GetSpellInfo(checkName);
		if (tested) then
			-- reverse order
			return { word }
		end
	end

	return nil, true
end	

local function GetSpellbookRankWord(book)
	local index = 1;
	local word, lookMore = GetSpellbookItemRankWord(index, book);
	local escape = 0;
	if (_.isValue(word) or not lookMore) then return word end;
	while(not word) do
		index = index + 1;
		word, lookMore = GetSpellbookItemRankWord(index, book);
		if (_.isValue(word) or not lookMore) then return word end
		escape = escape + 1;
		if (escape > 300) then
			_.print("GetSpellbookRankWord will run forever. preventive escape");
			return;
		end
	end
end

local rankWordByLocales = {
	["ruRU"] = "Уровень",
	["enGB"] = "Rank",
	["enUS"] = "Rank",
	["koKR"] = { "레벨" }, -- REVERT ORDER: Shadow bolt(1 Rank),
	["zhTW"] = "等级",
	["zhCN"] = "等级",
	["esMX"] = "Rango",
	["esES"] = "Rango",
	["ptBR"] = "Grau",
	["deDE"] = "Rang",
	["frFR"] = "Rang",
	["itIT"] = "Rank"
}

local function DetectSpellRankWord()
	local book = BOOKTYPE_PET;
	local locale = GetLocale();
	local word = rankWordByLocales[locale];
	if (_.isValue(word)) then
		return word;
	end

	word = GetSpellbookRankWord(BOOKTYPE_PET);
	if (_.isValue(word)) then
		return word;
	end

	return GetSpellbookRankWord(BOOKTYPE_SPELL);
end

_.GetSpellRankWord = function()
	local spellRank;
	if (not _.isValue(Tabu.vars.spellRankWord)) then
		local word = DetectSpellRankWord();
		if (type(word) == "table") then
			-- in case of table use revert order = rank goes first
			spellRank = {
				word = word[1],
				text = "%s(%s %s)",
				GetName = function(self, name, rank)
					return self.text:format(name, rank, self.word);
				end
			}
		elseif (_.isValue(word)) then
			spellRank = {
				word = word,
				text = "%s(%s %s)",				
				GetName = function(self, name, rank)
					return self.text:format(name, self.word, rank);
				end
			}
		end
		Tabu.vars.spellRankWord = spellRank;
	end
	if (not _.isValue(Tabu.vars.spellRankWord)) then
		_.print("|cffff0000Tabu-Bars unable to detect special \"Spell Rank\" word for local |cffffff00"..GetLocale().."|r.");
	end
	return Tabu.vars.spellRankWord;
end



local getRankedSpellBindingKeyExtra = function (spell, actualId)
	local command = "SPELL ";
	local rank = 1;
	local tryRanks = true;
	while(tryRanks) do
		--local rankText = "(Уровень "..rank.. ")";
		local rankedName = _.GetRankedSpellName(spell, rank);
		if (rankedName == spell) then return end
		local ranked, _, _, _, _, _, checkId = GetSpellInfo(rankedName);
		if (not ranked) then return end;
		if (checkId == actualId) then
			return GetBindingKey(command..rankedName);
		end
		rank = rank + 1;
	end
end

_.getSpellBindingKey = function (spell, actualId)
	
	local key = getRankedSpellBindingKeyExtra(spell, actualId);
	if (key) then
		return key;
	end
	
	-- fallback to unranked spell binding
	return GetBindingKey("SPELL "..spell);

end

_.getSpellCount = function(arg)
	local method = GetSpellCountFixed;
	if (not method) then
		method = GetSpellCount;
		--_.print("GetSpellCountFixed not installed, the default one instead");
	end
	local result = method(arg);
	if (result) then
		return result, "REAGENT"
	end
	local res = GetSpellPowerCost(arg);
	if (not res) then return end
	--print("# value is", type(res));
	for x, item in pairs(res) do
		if (item.name == "MANA") then
			if (item.cost) then
				local pm = UnitPower("player", 0);
				return math.floor(pm / item.cost), "MANA";
			end
		end
	end
end



_.round = function(number, digits)
	local pow;
	if (digits and digits > 0) then
		pow = 10 ^ digits;
		number = number * pow;
	end
	number = number % 1 >= 0.5 and math.ceil(number) or math.floor(number);
	if (pow) then
		number = number / pow;
	end
	return number;
end

_.getCooldown = function(_type, id)

	if (id and (_type == "spell" or _type == "Spell")) then
		return GetSpellCooldown(id);
	end

	if (id and type(id) == "number" and (_type == "item" or _type == "Item")) then
		return GetItemCooldown(id);
	end

end

_.isValue = function (arg)
	return arg ~= nil and arg ~= "";
end


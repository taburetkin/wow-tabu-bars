--controls
local A = Tabu:Addon(...);
local _ = A.utils;
local L = A.localization.Get;
Tabu.Controls = {}

local ANCHORPOINTS = { "TOPLEFT", "TOPRIGHT", "BOTTOMLEFT", "BOTTOMRIGHT", "LEFT", "TOP", "RIGHT", "BOTTOM", "CENTER" };

local C = Tabu.Controls;
C.ControlBuilders = {};
C.FontPath = "Fonts\\ARIALN.ttf";



C.SetControlBuilder = function(controlType, builder)
	C.ControlBuilders[controlType] = builder;
end

C.GetControlBuilder = function(controlType)
	return C.ControlBuilders[controlType];
end

C.ControlFrameMixin = {
	ShouldSkip = function(self)
		if (type(self.context.shouldSkip) == "function") then			
			return self.context:shouldSkip(self:GetParent():GetEntity());
		end
	end,
	UpdateAnchor = function(self, previous, options)
		local settingsFrame = self:GetParent();
		self:SetWidth(settingsFrame:GetWidth() - 20);
		self:ClearAllPoints();
		if (not previous) then
			if (options and options.firstPoint) then
				self:SetPoint(unpack(options.firstPoint));
			else
				self:SetPoint("TOPLEFT", 10, -10);
			end
		else
			self:SetPoint("TOPLEFT", previous, "BOTTOMLEFT", 0, -5);
		end
	end,
	ApplyFormValue = function(self, previous, options)
		self:Hide();
		if (self:ShouldSkip()) then
			return;
		end

		self:UpdateAnchor(previous, options);
		
		local val = C.GetValueForControl(self.context, self:GetParent():GetEntity());
		if (val == nil and self.context.defaultValue) then
			val = self.context.defaultValue;
		end

		self:SetControlValue(val);
		self:Show();
	end,
	GetControlValue = function(self)
		return self.control:GetControlValue();
	end,
	SetControlValue = function(self, ...)
		return self.control:SetControlValue(...);
	end,
}

C.GetColorPickerValue = function()
	if (not ColorPickerFrame:IsShown()) then return end;
	local r, g, b = ColorPickerFrame:GetColorRGB();
	local a = OpacitySliderFrame:GetValue();
	return r, g, b, a
end


C.ShowColorPicker = function(changeCb, r, g, b, a)
	local cb = function()
		changeCb(C.GetColorPickerValue())
	end
	ColorPickerFrame:SetColorRGB(r,g,b);
	ColorPickerFrame.hasOpacity, ColorPickerFrame.opacity = (a ~= nil), a;
	ColorPickerFrame.previousValues = { r , g, b, a };
	ColorPickerFrame.func, ColorPickerFrame.opacityFunc = cb, cb;
	ColorPickerFrame.cancelFunc = function()
		changeCb(unpack(ColorPickerFrame.previousValues));
	end
	ColorPickerFrame:Hide(); -- Need to run the OnShow handler.
	ColorPickerFrame:Show();	
end


local function createEditFrameLabel(edit, label)
	edit.label = edit:CreateFontString(nil, "ARTWORK"); 
	edit.label:SetPoint("LEFT", 0, 0);
	edit.label:SetFont(C.FontPath, 16);
	edit.label:SetText(L(label));
end

local function createEditFrame(parent, context)
	local edit = CreateFrame("Frame", nil, parent);
	edit:Hide();
	edit:SetHeight(40);
	createEditFrameLabel(edit, context.label);
	_.mixin(edit, C.ControlFrameMixin);
	return edit;
end
C.CreateEditFrame = createEditFrame;

local function hashDropdownInit(hash, control, shouldBeSkiped)
	local info;
	if (not shouldBeSkiped) then
		shouldBeSkiped = function() end;
	end
	control.GetValueText = function(self)
		return hash[self._value];
	end
	control.initialize = function(self)
		for value, label in pairs(hash) do
			local skip = shouldBeSkiped(value);
			if (not skip) then
				info = UIDropDownMenu_CreateInfo();
				info.text = label;
				info.arg1 = value;
				info.func = control.ClickHandler;
				info.checked = control:IsValueEqual(value)
			end
			UIDropDownMenu_AddButton(info, 1);
		end
	end
end
local function createDropDown(parent, make)
	local control = CreateFrame("Frame", nil, parent, "UIDropDownMenuTemplate");
	UIDropDownMenu_SetWidth(control, 145)
	control:SetSize(178, 30);
	control:SetPoint("RIGHT", parent, "RIGHT");	
	control.GetValueText = function(self)
		return self._value;
	end
	control.GetControlValue = function(self) 
		return self._value;
	end
	control.SetControlValue = function(self, value, text) 
		--value = NormalizeNil(value);
		self._value = value;
		if (not _.isValue(text)) then
			text = self:GetValueText();
		end
		UIDropDownMenu_SetText(self, text);
	end;
	control.IsValueEqual = function(self, ...)
		local selfValue = self:GetControlValue();
		local value = select(1, ...);
		if (selfValue == value) then return true end
		if (type(selfvalue) == "table") then
			for x,xv in pairs(selfvalue) do
				if (xv ~= select(x, ...)) then return false end
			end
			return true;
		end
		return false;
	end
	control.ClickHandler = function(self, arg1, arg2, checked)
		if (not arg2) then
			control:SetControlValue(arg1);
		else
			control:SetControlValue({ arg1, arg2 });
		end
	end	
	make(control);
	return control;
end
C.CreateDropdownControl = createDropDown;

local function NormalizeNil(arg)
	if (arg == '[nil]') then
		return nil
	else
		return arg
	end
end

--#region NUMBER
local function NumberEditFrame(parent, context)

	local edit = createEditFrame(parent, context);

	local control = CreateFrame("EditBox", nil, edit, "InputBoxTemplate");
	control:SetFont(C.FontPath, 16);
	control:SetPoint("RIGHT", edit, "RIGHT", 0, 0);
	control:SetSize(90, 30);
	control:SetAutoFocus(false);
	control.SetControlValue = function(self, text)
		text = NormalizeNil(text);
		local val = tostring(text or "");
		if (context.beforeValueSet) then
			val = context.beforeValueSet(val);
		end
		self:SetText(val);
	end
	control.GetControlValue = function(self)
		local value = self:GetNumber();
		if (not value) then
			return nil;
		end
		return value;
	end

	edit.control = control;

	return edit;
end
C.SetControlBuilder("number", NumberEditFrame);
--#endregion NUMBER

--#region POINT
local function makePointDropdown(control, shouldBeSkiped)
	local info;
	if (not shouldBeSkiped) then
		shouldBeSkiped = function() end;
	end
	control.initialize = function(self)
		for _, point in pairs(ANCHORPOINTS) do
			local skip = shouldBeSkiped(point);
			if (not skip) then
				info = UIDropDownMenu_CreateInfo();
				info.text = point;
				info.arg1 = point;
				info.func = control.ClickHandler;
				info.checked = control:IsValueEqual(point)
			end
			UIDropDownMenu_AddButton(info, 1);
		end
	end
end
local function PointEditFrame(parent, context)
	local edit = createEditFrame(parent, context);	
	edit.control = createDropDown(edit, makePointDropdown);
	return edit;
end
C.SetControlBuilder("point", PointEditFrame);
--#endregion


--#region COLOR
local function ColorEditFrame(parent, context)
	local edit = createEditFrame(parent, context);

	local clr = CreateFrame("Button", nil, edit);
	clr:SetPoint("RIGHT", edit, "RIGHT", -2, 0);
	clr:SetSize(90, 40);

	local t = clr:CreateTexture(nil, "BACKGROUND");
	t:SetAllPoints();
	clr.bg = t;
	
	clr.text = clr:CreateFontString(nil, "OVERLAY");
	clr.text:SetFont("FONTS\\ARIALN.ttf", 10, "THICKOUTLINE");
	clr.text:SetPoint("TOPLEFT", clr, "TOPLEFT", 1, -1);
	clr.text:SetJustifyH("LEFT");

	local frm = "R: %s\nG: %s\nB: %s\nA: %s";
	clr.text.UpdateText = function(self, r, g, b, a)
		r = r and _.round(r, 5) or "";
		g = g and _.round(g, 5) or "";
		b = b and _.round(b, 5) or "";
		a = a and _.round(a, 5) or "";
		self:SetText(string.format(frm, r,g,b,a));
	end


	clr:SetScript("OnClick", function() 
		Tabu.Controls.ShowColorPicker(function(r,g,b,a) 
			if (r and g and b) then
				edit:SetControlValue({r,g,b,a});
			end
		end, unpack(edit:GetControlValue()))
	end)
	
	edit.control = clr;

	
	edit.GetControlValue = function(self)
		return self._controlValue;
	end
	edit.SetControlValue = function(self, value)
		if (value == nil) then
			value = { 0, 0, 0, .8 };
		end
		self._controlValue = value;
		self.control.bg:SetColorTexture(unpack(value));
		self.control.text:UpdateText(unpack(value));
	end	

	return edit;
end
C.SetControlBuilder("color", ColorEditFrame);
--#endregion


--#region FONT edit
local function makeFontDropdown(parent, context)
	local hash;
	local varType = type(context.sourceValues);
	if (varType == 'function') then
		hash = context.sourceValues();
	elseif (varType == 'table') then
		hash = context.sourceValues;
	else
		hash = {};
	end
	return function(control, shouldBeSkiped)
		hashDropdownInit(hash, control, shouldBeSkiped);
	end
end
local function FontEditFrame(parent, context)
	local edit = createEditFrame(parent, context);
	edit.control = createDropDown(edit, makeFontDropdown(parent, context));
	return edit;
end
C.SetControlBuilder("font", FontEditFrame);
--#endregion



C.GetValueForControl = function (cntx, entity)
	if (type(cntx.getEntityValue) == "function") then
		return cntx.getEntityValue(entity);
	end
	if (type(cntx.key) == "table") then
		local res = {};
		for _, key in pairs(cntx.key) do
			local v = entity[key];
			table.insert(res, v);
		end
		return res;
	else
		return entity[cntx.key];
	end
end


C.GetFormControlValue = function(control, resultTable)
	resultTable = resultTable or {};
	if (not control or not control.controlFrame or not control.controlFrame:IsShown()) then 
		return resultTable;
	end;
	local value = control.controlFrame:GetControlValue();
	if (type(control.key) == "table") then
		if (type(value) ~= "table") then
			value = { value };
		end
		for ind, key in pairs(control.key) do
			resultTable[key] = value[ind];
		end
	else
		resultTable[control.key] = value;
	end
	return resultTable;
end

C.GetFormValue = function(controls)
	local res = {}
	for x, control in pairs(controls) do
		C.GetFormControlValue(control, res);
	end
	return res;
end

C.ApplyFormValuesToEntity = function(entity, values)
	for k,v in pairs(values) do
		entity[k] = v;
	end
end







C.BuildControlFrame = function(cfgFrame, context)
	
	local controlType = context.control;
	local controlFrame;

	

	local builder = C.GetControlBuilder(controlType);
	
	if (type(builder) ~= "function") then
		error("Unknown control builder: ".. controlType);
	end

	controlFrame = builder(cfgFrame, context);
	if (not controlFrame) then return end;
	

	controlFrame.context = context;
	return controlFrame;
end


local configs = {};

local configFrames = {};
local configFramesControls = {};
local configFramesMixins = {};
local configFramesSetups = {};

C.ConfigFrameMixin = {
	SetControls = function(self, controls)
		self.controls = controls;
	end,

	GetControls = function(self) 
		return self.controls;
	end,

	GetEntity = function(self) 
		return self.entity;
	end,

	SetEntity = function(self, entity) 
		self.entity = entity;
	end,

	GetValue = function(self)
		local controls = self:GetControls();
		return C.GetFormValue(controls);
	end,

	AfterApplyValues = function(self) end, -- MUST BE OVERRIDED

	ApplyFormValues = function(self)
		local values = self:GetValue();
		local entity = self:GetEntity();
		C.ApplyFormValuesToEntity(entity, values);
		if (type(self.OwnAfterApply) == 'function') then
			self:OwnAfterApply();
		else
			self:AfterApplyValues();
		end
	end,

	InitForm = function(self, entity, afterApply)
		self.OwnAfterApply = afterApply;
		self:SetEntity(entity);
		self:UpdateFrameValues(); --applyValuesToConfigFrame(self);
	end,
	GetControlsParent = function(self)
		return self._controlsParent or self;
	end,
	SetControlsParent = function(frame, parent)
		frame._controlsParent = parent;
		parent.GetEntity = function()
			return frame:GetEntity();
		end
	end,	
	UpdateFrameValues = function(frame)
		local parent = frame:GetControlsParent();
		local controls = frame:GetControls();
		local previousControlFrame;
		local firstPoint = { "TOPLEFT", 10, 0 };
		frame.childrenHeight = 0;
		local count = 0;
		for index, control in pairs(controls) do
			if (not control.id) then
				control.id = frame.formName .. "_CfgProp_"..index;
			end
			if (not control.controlFrame) then
				control.controlFrame = C.BuildControlFrame(parent, control);
			end
			if (control.controlFrame) then
				control.controlFrame:ApplyFormValue(previousControlFrame, { firstPoint = firstPoint });
				if (control.controlFrame:IsShown()) then
					previousControlFrame = control.controlFrame;
					frame.childrenHeight = frame.childrenHeight + control.controlFrame:GetHeight();
					count = count + 1;
				end
			end
		end
		parent:SetHeight(frame.childrenHeight + (count - 1)*5);
		frame:Refresh();
	end,
	Refresh = function(self)
		local content = self:GetControlsParent();
		if (content == self) then return end
		local addHeight = 80;
		local maxUnscroll = 400 + addHeight;
		local height = content:GetHeight();
		local mainFrameHeight = height + addHeight;
		
		if (mainFrameHeight > maxUnscroll) then
			self:SetHeight(maxUnscroll);
		else
			self:SetHeight(mainFrameHeight);
		end
	end,
	TabClicked = function(self, tabButton)
		if (self._currentTab) then 
			self._currentTab:MakeInActive();
		end;
		self._currentTab = tabButton;
	end
}


local function setupConfigFrame(frame, setup, name)
	_.mixin(frame, C.ConfigFrameMixin);
	frame:SetControls(setup.controls);
	frame.formName = name;
	local mixin = setup.mixin; --configFramesMixins[name];
	if (type(mixin) == "table") then
		_.mixin(frame, mixin);
	end
	local setup = setup.setup; --configFramesSetups[name];
	if (type(setup) == "function") then
		setup(frame, name);
	end
end

local function setupConfigTabs(frame, tabs)
	if (not tabs) then return end;
	local prevTab;
	if (not frame.tabs) then
		frame.tabs = {};
	end
	for i, tab in ipairs(tabs) do		
		local button = CreateFrame("Button", nil, frame);		
		button:RegisterForClicks("AnyUp");
		--button:("GameFontNormalSmall")
		local fs = button:CreateFontString(nil, "OVERLAY");
		fs:SetFont("FONTS\\ARIALN.ttf", 10);
		fs:SetText(L(tab.name));
		fs:SetPoint('LEFT', button, 'LEFT', 10, 0);
		fs:SetTextColor(1,1,1,1);
		local width = fs:GetStringWidth();
		button:SetFontString(fs);
		button:SetSize(width+20, 26);

		button.group = tab.group;
		table.insert(frame.tabs, button);

		button.bg = _.createColorTexture(button, 0, 0, 0, 0.5, "BACKGROUND");
		button.hlbg = _.createColorTexture(button, 1, 1, 1, 0.1, "BORDER");
		button.hlbg:Hide();
		button.chbg = _.createColorTexture(button, .25,.25,.25,.9, "ARTWORK");
		button.chbg:Hide();

		button.GetChecked = function(self)
			return self._checked == true;
		end
		button.SetChecked = function(self, value)
			self._checked = (value == true);
		end
		button.MakeActive = function(self)
			self:SetChecked(true);
			self.chbg:Show();
		end
		button.MakeInActive = function(self)
			self:SetChecked(false);
			self.chbg:Hide();
		end

		button.OnEnter = function(self) self:ShowHighlightBg(); end;
		button.OnLeave = function(self) self:HideHighlightBg(); end;
		button.OnClick = function(self) 
			local che = self:GetChecked();
			if (che) then return end;
			self:GetParent():TabClicked(self);
			self:MakeActive();
		end
		button.ShowCheckedBg = function(self) self.chbg:Show(); end
		button.HideCheckedBg = function(self) self.chbg:Hide(); end
		button.ShowHighlightBg = function(self) self.hlbg:Show(); end
		button.HideHighlightBg = function(self) self.hlbg:Hide(); end		

		button:SetScript("OnClick", button.OnClick)
		button:SetScript("OnEnter", button.OnEnter)
		button:SetScript("OnLeave", button.OnLeave)



		--button:SetNormalTextColor(1,.5,.5,1);

		--button.NormalFontObject:SetFont("FONTS\\ARIALN.ttf", 10);
		--_.createColorTexture(button, 0,0,0,1);


		-- local tx = button:CreateTexture(nil, "BACKGROUND");
		-- tx:SetColorTexture(0,0,0, 1);
		-- tx:SetAllPoints();
		-- button:SetNormalTexture(tx);

		-- tx = button:CreateTexture(nil, "BACKGROUND");
		-- tx:SetColorTexture(.1, .1, .1, 1);
		-- tx:SetAllPoints();
		-- button:SetHighlightTexture(tx, "BLEND");

		-- tx = button:CreateTexture(nil, "BACKGROUND");
		-- tx:SetColorTexture(.2, .2, .2, 1);
		-- tx:SetAllPoints();
		-- button:SetCheckedTexture(tx, "BLEND");

		-- button:SetScript("OnEnter", function(self) 
		-- 	C_Timer.After(.3, function() 
		-- 		deprint('#', self:GetButtonState());
		-- 	end)
		-- end)
		--button:SetScript("OnLeave", function(self) self:SetButtonState("NORMAL", false); end);


		if (not prevTab) then
			button:SetPoint("BOTTOMLEFT", frame, "TOPLEFT", 10, 0);
		else
			button:SetPoint("BOTTOMLEFT", prevTab, "BOTTOMRIGHT", 2, 0);
		end
		prevTab = button;
	end
end

C.CreateConfigFrame = function(name, setup)
	local frame = _.createDialogFrame({
		name = A.Name .. "_" .. name .. "Frame",
		bg = { .15,.15,.15,.9,"BACKGROUND" }
	});


	frame:SetFrameLevel(UIParent:GetFrameLevel() + 100);
	frame:SetPoint("CENTER");
	frame:SetSize(450, 300);

	--setupConfigTabs(frame, setup.tabs);

	setupConfigFrame(frame, setup, name);


	local scrollFrame = CreateFrame("ScrollFrame", "$parent_Scroll", frame, "UIPanelScrollFrameTemplate");
	scrollFrame:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -28, -26);
	scrollFrame:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 0, 36);
	--scrollFrame:SetAllPoints();
	local contentFrame = CreateFrame("Frame");
	contentFrame:SetPoint("TOPLEFT", scrollFrame, "TOPLEFT", 0, 0);
	contentFrame:SetWidth(scrollFrame:GetWidth());
	scrollFrame:SetScrollChild(contentFrame);
	--contentFrame:SetAllPoints();
	frame:SetControlsParent(contentFrame);
	frame.scroll = scrollFrame;

	local save = CreateFrame("Button", nil, frame, "OptionsButtonTemplate");
	save:SetText(L("Save Changes"));
	save:SetSize(150, 26);
	save:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 5, 5);
	save:SetScript("OnClick", function(self) 
		frame:ApplyFormValues();
	end);

	local close = CreateFrame("Button", nil, frame, "OptionsButtonTemplate");
	close:SetText(L("Close"));
	close:SetSize(90, 26);
	close:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -5, 5);
	close:SetScript("OnClick", function() frame:Hide() end);

	frame:Hide();

	return frame;
end

C.GetConfigFrame = function(name)
	local setup = configs[name];
	if (not setup) then
		error("Not registered config settings: ".. (name or ''));
	end
	if (not setup.frame) then
		setup.frame = C.CreateConfigFrame(name, setup);
	end
	return setup.frame;
	-- if (not configFrames[name]) then
	-- 	local controls = configFramesControls[name];
	-- 	configFrames[name] = C.CreateConfigFrame(name, controls);
	-- end
	-- return configFrames[name];
end

C.ShowSettings = function(name, entity, afterApply)
	if (not entity) then return end
	local frame = C.GetConfigFrame(name);
	frame:InitForm(entity, afterApply);
	C_Timer.After(.1, function() 
		frame:Show();
	end)
end

C.RegisterSettings = function(name, data)
	configs[name] = _.cloneTable(data, true);
	-- configFramesControls[name] = data.controls;
	-- configFramesMixins[name] = data.mixin;
	-- configFramesSetups[name] = data.setup;
end

local A, _, L, Cache = Tabu:Spread(...);


local specialbars = {
	["SpellbookTabs"] = {
		
	}
}

A.SBar = {

}

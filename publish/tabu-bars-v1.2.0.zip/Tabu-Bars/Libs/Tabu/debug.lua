local A = Tabu:Addon(...);
local _ = A.utils;
--local Tabu = {};



_.debugOn = function()
	local c = A:GetCache();
	c.debug = true;
	_.print("|cffeeeeeedebug|r |cffffffffON|r");
end

_.debugOff = function()
	local c = A:GetCache();
	c.debug = nil;
	_.print("|cffeeeeeedebug|r |cffffffffOFF|r")
end

_.isDebug = function()
	return A:GetCache().debug == true;
end

A.debug = function()
	if (_.isDebug()) then
		_.debugOff();
	else
		_.debugOn();
	end
end


if A.Tabu__Initialized then return end



local dumpFrame;

local function TabuDumpFrame()
	if (dumpFrame) then 
		return dumpFrame;
	end

	local frame = CreateFrame("Frame", nil, UIParent);
	frame:SetFrameLevel(UIParent:GetFrameLevel() + 100);
	frame:SetPoint("CENTER");
	frame:SetSize(800, 600);

	

	local t = frame:CreateTexture();
	t:SetAllPoints();
	t:SetColorTexture(0,0,0, 0.75);

	frame:SetBackdrop({
		edgeFile = [[Interface\Buttons\WHITE8x8]],
		edgeSize = 1,		
	});
	frame:SetBackdropBorderColor(0.15, 0.15, 0.15, 1);

	frame:EnableMouse(true);
	frame:SetMovable(true);
	frame:RegisterForDrag("LeftButton");
	frame:SetScript("OnDragStart", function(self) self:StartMoving(); end);
	frame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end);

	local close = CreateFrame("Button", nil, frame, "OptionsButtonTemplate");
	close:SetText("Close");
	close:SetSize(90, 26);
	close:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -5, 5);
	close:SetScript("OnClick", function() frame:Hide() end);

	local scroll = CreateFrame("ScrollFrame", nil, frame, "UIPanelScrollFrameTemplate");
	scroll:SetSize(frame:GetWidth()-30, frame:GetHeight()-40);
	scroll:SetPoint("TOPLEFT", 5 , -5);

	t = scroll:CreateTexture();
	t:SetAllPoints();
	t:SetColorTexture(0,0,0, 0.75);

	scroll:SetBackdrop({
		edgeFile = [[Interface\Buttons\WHITE8x8]],
		edgeSize = 1,		
	});
	scroll:SetBackdropBorderColor(0.15, 0.15, 0.15, 1);



	local content = CreateFrame("EditBox", nil, scroll);
	content:SetMultiLine(true);
	content:SetAutoFocus(false);
	content:SetFont("Fonts\\ARIALN.TTF", 12);
	content:SetSize(scroll:GetWidth(), scroll:GetHeight());
	content:SetPoint("TOPLEFT", 0, 0);
	scroll:SetScrollChild(content);
	
	frame.content = content;
	dumpFrame = frame;
	return frame;
end

local function dumpvar(o, level)
	local res;
	local shouldPrint = not level;
	if (o == nil) then
		o = "[nil]";
	elseif (o == "") then
		o = "[empty string]";
	end
	if (not level) then
		level = 1;
	end
	local indent = string.rep(' ', 2 * (level + 1));
	local indentL = string.rep(' ', 2 * level);
	if type(o) == 'table' then
		res = '{ \n'
		for k,v in pairs(o) do
			if type(k) ~= 'number' then k = '"'..k..'"' end		  
			res = res .. indent .. '['..k..'] = ' .. dumpvar(v, level + 1) .. ',\n'
		end
		res = res .. indentL .. '}'
	else
	   res = tostring(o);
	end
	return res;
end

Tabu.print = function (o)
	print(dumpvar(o));
end

Tabu.dump = function (o)
	local text = dumpvar(o);
	local frame = TabuDumpFrame();
	if (not text) then text = "" end;
	frame.content:SetText(text);
	frame:Show();
end

local runFrame;

local function getRunFrame()
	if (not runFrame) then

		local frame = CreateFrame("Frame", nil, UIParent);
		frame:SetFrameLevel(UIParent:GetFrameLevel() + 100);
		frame:SetPoint("CENTER");
		frame:SetSize(800, 600);
	
		
	
		local t = frame:CreateTexture();
		t:SetAllPoints();
		t:SetColorTexture(0,0,0, 0.75);
	
		frame:SetBackdrop({
			edgeFile = [[Interface\Buttons\WHITE8x8]],
			edgeSize = 1,		
		});
		frame:SetBackdropBorderColor(0.15, 0.15, 0.15, 1);
	
		frame:EnableMouse(true);
		frame:SetMovable(true);
		frame:RegisterForDrag("LeftButton");
		frame:SetScript("OnDragStart", function(self) self:StartMoving(); end);
		frame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end);
	
		local close = CreateFrame("Button", nil, frame, "OptionsButtonTemplate");
		close:SetText("Close");
		close:SetSize(90, 26);
		close:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -5, 5);
		close:SetScript("OnClick", function() frame:Hide() end);
	

		local scroll = CreateFrame("ScrollFrame", nil, frame, "UIPanelScrollFrameTemplate");
		scroll:SetSize(frame:GetWidth()-30, frame:GetHeight()-40);
		scroll:SetPoint("TOPLEFT", 5 , -5);
	
		t = scroll:CreateTexture();
		t:SetAllPoints();
		t:SetColorTexture(0,0,0, 0.75);
	
		scroll:SetBackdrop({
			edgeFile = [[Interface\Buttons\WHITE8x8]],
			edgeSize = 1,		
		});
		scroll:SetBackdropBorderColor(0.15, 0.15, 0.15, 1);
	
	
	
		local content = CreateFrame("EditBox", nil, scroll);
		content:SetMultiLine(true);
		content:SetAutoFocus(false);
		content:SetFont("Fonts\\ARIALN.TTF", 16);
		content:SetSize(scroll:GetWidth(), scroll:GetHeight());
		content:SetPoint("TOPLEFT", 0, 0);
		content:SetScript("OnEscapePressed", function(self) 
			self:ClearFocus();
		end)
		scroll:SetScrollChild(content);		
		frame.content = content;

		local run = CreateFrame("Button", nil, frame, "OptionsButtonTemplate");
		run:SetText("Run");
		run:SetSize(90, 26);
		run:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 5, 5);
		run:SetScript("OnClick", function() 
			RunScript(content:GetText())
		end);



		runFrame = frame;
	end
	return runFrame;
end

Tabu.run = function ()
	local frame = getRunFrame();
	frame:Show();
end



if (type(deprint) ~= "function") then
	deprint = function(...)
		if (not _.isDebug()) then return end
		print(...);
	end
end


-- A.TabuInitDebug = function()
-- 	for key, fn in pairs(_) do
-- 		A.utils[key] = fn;
-- 	end

-- 	A.debug = function()
-- 		if (_.isDebug()) then
-- 			_.debugOff();
-- 		else
-- 			_.debugOn();
-- 		end
-- 	end


-- 	local TabuAddon = _G["Tabu"];
-- 	for key, fn in pairs(Tabu) do
-- 		TabuAddon[key] = fn;
-- 	end

-- 	if (type(deprint) ~= "function") then
-- 		deprint = function(...)
-- 			if (not _.isDebug()) then return end
-- 			print(...);
-- 		end
-- 	end

-- end

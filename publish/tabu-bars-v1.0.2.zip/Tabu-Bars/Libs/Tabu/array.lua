local A = Tabu:Addon(...);
local _ = A.utils;


_.arrayHasAny = function (where, what)
	for _, v1 in pairs(where) do
		for _, v2 in pairs(what) do
			if (v1 == v2) then return true end
		end
	end
	return false;
end

_.arrayHasValue = function(tbl, value)
	for i, v in pairs(tbl) do
		if (v == value) then return true end
	end
	return false;
end

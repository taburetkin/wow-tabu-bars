local A = Tabu:Addon(...);
local _ = A.utils;


local dumpFrame;

local function TabuDumpFrame()
	if (dumpFrame) then 
		return dumpFrame;
	end

	local frame = CreateFrame("Frame", nil, UIParent);
	frame:SetFrameLevel(UIParent:GetFrameLevel() + 100);
	frame:SetPoint("CENTER");
	frame:SetSize(800, 600);

	

	local t = frame:CreateTexture();
	t:SetAllPoints();
	t:SetColorTexture(0,0,0, 0.75);

	frame:SetBackdrop({
		edgeFile = [[Interface\Buttons\WHITE8x8]],
		edgeSize = 1,		
	});
	frame:SetBackdropBorderColor(0.15, 0.15, 0.15, 1);

	frame:EnableMouse(true);
	frame:SetMovable(true);
	frame:RegisterForDrag("LeftButton");
	frame:SetScript("OnDragStart", function(self) self:StartMoving(); end);
	frame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end);

	local close = CreateFrame("Button", nil, frame, "OptionsButtonTemplate");
	close:SetText("Close");
	close:SetSize(90, 26);
	close:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -5, 5);
	close:SetScript("OnClick", function() frame:Hide() end);

	local scroll = CreateFrame("ScrollFrame", nil, frame, "UIPanelScrollFrameTemplate");
	scroll:SetSize(frame:GetWidth()-30, frame:GetHeight()-40);
	scroll:SetPoint("TOPLEFT", 5 , -5);

	t = scroll:CreateTexture();
	t:SetAllPoints();
	t:SetColorTexture(0,0,0, 0.75);

	scroll:SetBackdrop({
		edgeFile = [[Interface\Buttons\WHITE8x8]],
		edgeSize = 1,		
	});
	scroll:SetBackdropBorderColor(0.15, 0.15, 0.15, 1);



	local content = CreateFrame("EditBox", nil, scroll);
	content:SetMultiLine(true);
	content:SetAutoFocus(false);
	content:SetFont("Fonts\\ARIALN.TTF", 12);
	content:SetSize(scroll:GetWidth(), scroll:GetHeight());
	content:SetPoint("TOPLEFT", 0, 0);
	scroll:SetScrollChild(content);
	
	frame.content = content;
	dumpFrame = frame;
	return frame;
end

local function dumpvar(o, level)
	local res;
	local shouldPrint = not level;
	if (o == nil) then
		o = "[nil]";
	elseif (o == "") then
		o = "[empty string]";
	end
	if (not level) then
		level = 1;
	end
	local indent = string.rep(' ', 2 * (level + 1));
	local indentL = string.rep(' ', 2 * level);
	if type(o) == 'table' then
		res = '{ \n'
		for k,v in pairs(o) do
			if type(k) ~= 'number' then k = '"'..k..'"' end		  
			res = res .. indent .. '['..k..'] = ' .. dumpvar(v, level + 1) .. ',\n'
		end
		res = res .. indentL .. '}'
	else
	   res = tostring(o);
	end
	return res;
end

function Tabu.print(o)
	print(dumpvar(o));
end

function Tabu.dump(o)
	local text = dumpvar(o);
	local frame = TabuDumpFrame();
	if (not text) then text = "" end;
	frame.content:SetText(text);
	frame:Show();
end



local currentId = 0;
local setUniqueId = function(id, shouldNotCache)
	currentId = id;
	if (not shouldNotCache) then
		local cache = A:GetCache();
		cache.uniqueidentifier = id;
	end
end

_.initializeUniqueId = function()
	local cache = A:GetCache();
	setUniqueId(cache.uniqueidentifier or 0, true);
end


_.updateUniqueId = function(item)
	if (item and item.rawId > currentId) then
		currentId = id;
	end
end

_.uniqueId = function(prefix)
	local newid = currentId + 1;

	setUniqueId(newid);

	if (prefix) then
		newid = prefix..newid;
	end
	return newid;
end

_.setId = function(item, prefix)
	item.rawId = _.uniqueId();
	if (prefix) then
		item.id = prefix .. item.rawId;
	else
		item.id = item.rawId;
	end
end

_.print = function(...)
	print("|cffff8000"..A.Name.."|r", ...);
end


local spellLinkTemplate = "|cff71d5ff|Hspell:%s|h[%s]|h|r";

_.GetSpellLink = function(name)
	local sname, __, __, __, __, __, sid = GetSpellInfo(name);
	return string.format(spellLinkTemplate, sid, sname);
end


_.GetSpellInfoTable = function(arg)
	local name, rank, icon, castTime, minRange, maxRange, id = GetSpellInfo(arg);	
	local tbl = {  
		id = id,
		name = name,
		rank = rank,
		icon = icon,
		castTime = castTime,
		minRange = minRange,
		maxRange = maxRange,
		link = _.GetSpellLink(id)
	}
	return tbl;
end

_.GetItemInfoTable = function(id)
	local name, link, rarity, level, minLevel, type, subType, stackCount, equipLoc, icon, sellPrice = GetItemInfo(id);
	return {
		id = id,
		name = name, 		
		link = link, 
		rarity = rarity, 
		level = level, 
		minLevel = minLevel, 
		type = type, 
		subType = subType, 
		stackCount = stackCount, 
		equipLoc = equipLoc, 
		icon = icon, 
		sellPrice = sellPrice
	}
end

_.GetMacroInfoTable = function (id)
	local name, icon, body, isLocal = GetMacroInfo(id)
	return {
		id = id,
		name = name,
		icon = icon,
		body,
		isLocal = isLocal
	}
end

_.buildFrameName = function(frameName)
	return A.Name .. "_" .. frameName;
end




local getRankedSpellBindingKeyExtra = function (spell, actualId)
	local command = "SPELL "..spell;
	local rank = 1;
	local tryRanks = true;
	while(tryRanks) do
		local rankText = "(Уровень "..rank.. ")";
		local ranked, _, _, _, _, _, checkId = GetSpellInfo(spell..rankText);
		if (not ranked) then return end;
		if (checkId == actualId) then
			return GetBindingKey(command..rankText);
		end
		rank = rank + 1;
	end
end

_.getSpellBindingKey = function (spell, actualId)
	local command = "SPELL "..spell;
	local key;

	key = getRankedSpellBindingKeyExtra(spell, actualId);
	if (key) then
		return key;
	end

	return GetBindingKey(command);

end

_.getSpellCount = function(arg)
	local method = GetSpellCountFixed;
	if (not method) then
		method = GetSpellCount;
		_.print("GetSpellCountFixed not installed, the default one instead");
	end
	return method(arg);
end

_.createColorTexture = function(frame, r, g, b, a)
	local t = frame:CreateTexture();
	t:SetAllPoints();
	t:SetColorTexture(r, g, b, a);
	return t;
end

_.addFrameBorder = function (frame, r, g, b, a)
	frame:SetBackdrop({
		edgeFile = [[Interface\Buttons\WHITE8x8]],
		edgeSize = 1,		
	});
	frame:SetBackdropBorderColor(r,g,b,a);
end

_.round = function(number, digits)
	local pow;
	if (digits and digits > 0) then
		pow = 10 ^ digits;
		number = number * pow;
	end
	number = number % 1 >= 0.5 and math.ceil(number) or math.floor(number);
	if (pow) then
		number = number / pow;
	end
	return number;
end


--##################################################
-- Tabu Core
-- local Addon, utils, L = Tabu:Spread(...);
-- internally uses Addon:Spread() so in case you need other spread you have to provide own spread method on the addon
-- local Addon = Tabu:Spread(...);
-- Addon.Spread = function(self) return whateverYouNeed end;
-- Do not modify Tabu.Spread, it may lead to unwanted results
--##################################################

if (not Tabu) then
	Tabu = {
		EnsureAddon = function(self, addon, name)

			if (addon._initialized) then return end;
			addon._initialized = true;
			addon.OriginalName = name;
			addon.Name = string.gsub(name, "[^%w_]", "");
			addon.CacheName = addon.Name .. "Data";
			_G[addon.Name] = addon;
			addon.utils = {};
			addon.localization = {
				locales = {},
				current = GetLocale(),
				Add = function (key, locale)
					addon.localization.locales[key] = locale;
				end,
				Get = function(key) 
					local locale = addon.localization.locales[addon.localization.current];
					local localized = locale and locale[key];
					if (not localized) then
						addon.utils.print(addon.localization.current, "Key not localized: ", key);
					end
					return localized or key;
				end
			}
			addon.CreateLocale = function(self, key, data)
				self.localization.locales[key] = data;
			end
			addon.GetCache = function(self)
				local cache =  _G[self.CacheName];
				if (not cache) then
					cache = {};
					_G[self.CacheName] = cache;
				end
				return cache;
			end
			local getCache = function() return addon:GetCache() end;
			addon.Spread = function(self)
				return self, self.utils, self.localization.Get, getCache;
			end
		end,		
		Addon = function(self, ...)
			local AddonName, addon = select(1, ...);
			self:EnsureAddon(addon, AddonName);
			return addon;
		end,		
		Spread = function (self, ...)
			local addon = self:Addon(...);
			return addon:Spread();
		end
	};
else
	--print("Tabu not null!");
end

local A = Tabu:Addon(...);

local _ = A.utils;
local L = A.localization.Get;

local processors = {};





local function GetProcessorsStore()
	return processors;
end

local function GetProcessor(name)
	local uname = string.upper(name);
	local store = GetProcessorsStore();
	return store[uname];
end

local function SetProcessor(processor)
	local store = GetProcessorsStore();
	store[processor.name] = processor;
	return processor;
end


local function CommandCommonValid(compareWithArgs, inputArgs)
	for i, compare in pairs(compareWithArgs) do
		if (inputArgs[i] ~= compare) then
			return false;
		end
	end
	return true;
end

local function CreateCommand(callback, argValues, mixWith)
	local Valid;
	local argValuesType = type(argValues);
	if (argValuesType == "function") then
		Valid = argValues;
	elseif (argValuesType == "table") then
		Valid = function(self, args)
			return CommandCommonValid(argValues, args);
		end
	else
		error("Unable to create ProcessorCommand argValues must be a function or table")
	end
	local command = {
		arguments = argValues,
		Valid = Valid,
		Call = callback
	}
	if (type(mixWith) == "table") then
		_.mixin(command, mixWith);
	end
	return command;
end




local ProcessorMixin = {
	AddCommand = function(self, command, args, mixWith)
		local commandType = type(command);
		if (commandType == "function") then
			local callback = command;
			command = CreateCommand(callback, args, mixWith);
		elseif (commandType == "table") then
			command = parse;
		else
			error("AddCommand bad arguments. command must be a function or table");
		end

		if (
			type(command) ~= "table"
			or type(command.Valid) ~= "function"
			or type(command.Call) ~= "function"
		) then
			error("Bad AddCommand argument. Command must be a table with \"Valid\" and \"Call\" methods");
		end
		table.insert(self.commands, command);
	end,
	ProcessCommand = function(self, text)
		if (text == nil) then
			text = "";
		end
		local arguments = { strsplit(" ", text) };
		for i, command in pairs(self.commands) do
			if (command:Valid(arguments)) then
				if (command.arguments) then
					local size = _.size(command.arguments);
					command:Call(select(size + 1, unpack(arguments)));
				else
					command:Call(unpack(arguments));
				end
				return;
			end
		end
		_.print(L("Unknown chat command"), text);
	end
}

local function CreateProcessor(name)
	local processor = {
		name = string.upper(name),
		commands = {},
	};
	_.mixin(processor, ProcessorMixin);
	return processor;
end

local function EnsureProcessor(uname)
	if (not GetProcessor(uname)) then
		local processor = CreateProcessor(uname);
		SetProcessor(processor);
		SlashCmdList[uname] = function(text)
			processor:ProcessCommand(text);
		end
	end
	return GetProcessor(uname);
end

A.ChatCommands = {
	Register = function(name, ...)
		local cmd;
		local uname = string.upper(name);
		for i = 1, select("#", ...) do
			cmd = select(i, ...);
			_G["SLASH_"..uname..i] = cmd;
		end
		return EnsureProcessor(uname);
	end,
	AddCommand = function(processorName, callback, args, mixWith)
		local processor = GetProcessor(processorName);
		if (not processor) then
			error("Processor not found. Use ChatCommands.Register for register a chat command processor");
		end
		if (type(callback) == "table") then
			processor:AddCommand(callback);
		elseif (type(callback) == "function") then
			processor:AddCommand(true, callback, args, mixWith);
		end
		--local command = CreateCommand(callback, args, mixWith);
	end
}

if A.Tabu__Initialized then return end

local tabuProcessor = A.ChatCommands.Register("Tabu", "/tabu");
tabuProcessor:AddCommand(function(self, ...) 
	Tabu.run();	
end, {"run"});



local A = Tabu:Addon(...);
--if A.Tabu__Initialized then return end
local _ = A.utils;
local L = A.localization.Get;

-- A.TabuInitTable = function()
-- 	for key, fn in pairs(_) do
-- 		A.utils[key] = fn;
-- 	end
-- end

_.size = function(tbl)
	local size = 0;
	for i, v in pairs(tbl) do
		size = size + 1;
	end
	return size;
end

_.updateTable = function (dst, src, debug)
	if (type(dst) ~= "table" or type(src) ~= "table") then
		error("One of Mixin arguments is not a table");
		return;
	end
	for key, val in pairs(src) do
		dst[key] = src[key]
	end
	return dst;
end
_.mixin = _.updateTable;

_.localizeKeys = function(tbl)
	local localized = {};
	for key, value in pairs(tbl) do
		localized[L(key)] = value;
	end
	return localized;
end


_.cloneTable = function(tbl, notDeep, ...)
	if (type(tbl) ~= "table") then return end;
	local res = {};
	local index = 1;
	local isArray = false;
	local keyed = select("#", ...) > 0;
	local keys = { ... };
	local data = tbl;
	if (keyed == true) then
		data = keys;
	end
	for k,v in pairs(data) do
		local value;
		if (keyed) then
			value = tbl[v];
		else
			value = v;
		end

		if (type(value) == "table" and notDeep ~= true) then
			value = _.cloneTable(value);
		end

		if (index == 1) then
			if (keyed) then
				isArray = type(v) == "number";
			else
				isArray = k == 1;
			end
		end

		if (isArray) then
			table.insert(res, value);
		else
			local key = keyed and v or k;
			res[key] = value;
		end

		index = index + 1;
	end
	return res;
end

local A = Tabu:Addon(...);
A._utilsCurrentId = 0;

if not A._InitializeTabu then
	A.utils = A.Tabu.utils;
	return;
else
	A.Tabu.utils = {};
	A.utils = A.Tabu.utils;
end

--local currentId = 0;


local _ = A.utils;


_.print = function(...)
	print("|cffff8000"..A.Name.."|r", ...);
end

local setUniqueId = function(id, shouldNotCache)
	A._utilsCurrentId = id;
	if (not shouldNotCache) then
		local cache = A:GetCache();
		cache.uniqueidentifier = id;
	end
end

_.initializeUniqueId = function()
	local cache = A:GetCache();
	setUniqueId(cache.uniqueidentifier or 0, true);
end


_.updateUniqueId = function(item)
	local currentId = A._utilsCurrentId;
	if (item and item.rawId > currentId) then
		A._utilsCurrentId = id;
		--currentId = id;
	end
end

_.uniqueId = function(prefix)
	local currentId = A._utilsCurrentId;
	local newid = currentId + 1;

	setUniqueId(newid);

	if (prefix) then
		newid = prefix..newid;
	end
	return newid;
end

_.setId = function(item, prefix)
	item.rawId = _.uniqueId();
	if (prefix) then
		item.id = prefix .. item.rawId;
	else
		item.id = item.rawId;
	end
end




local spellLinkTemplate = "|cff71d5ff|Hspell:%s|h[%s]|h|r";
_.GetSpellLink = function(arg, fullname)
	local sname, __, __, __, __, __, sid = GetSpellInfo(arg);
	sname = fullname or sname;
	return string.format(spellLinkTemplate, sid, sname);
end



_.GetRankedSpellName = function(spell, rank, shouldDebug)

	if (type(rank) ~= "number") then
		error("Wrong argument type. rank must be a number");
	end

	if (not _.isValue(spell)) then return end
	if (not _.isValue(rank)) then return spell end
	local rankWord = _.GetSpellRankWord();
	if (not rankWord) then return spell; end
	--Tabu.print(rankWord);
	return rankWord:GetName(spell, rank);

end


_.GetRankedSpellInfo = function(id, name, shouldDebug)
	if (not id) then return name end
	local s, rankedName, rankSpell, currentName, currentRank, maxRank;
	
	local log = shouldDebug and print or function() end;

	local index = 1;
	local stop = false;

	while (not stop) do

		rankedName = _.GetRankedSpellName(name, index, shouldDebug);

		if (rankedName == name) then
			return name;
		end

		--log('INFO:', rankedName, "::", GetSpellBookItemInfo(rankedName, BOOKTYPE_SPELL));

		rankSpell, s, s, s, s, s, rankId  = GetSpellInfo(rankedName);

		--log('##', rankSpell, rankedName, rankId);

		if (not rankSpell) then
			if (index == 1) then
				return name;
			end
			stop = true;
			break;
		end
		if (id == rankId) then
			currentName = rankedName
			currentRank = index;
		end
		index = index + 1;
	end
	maxRank = index - 1;
	return currentName, currentRank, maxRank, currentRank == maxRank
end



_.GetSpellInfoTable = function(arg, shouldDebug)
	local byId = type(arg) == "number";

	-- if (byId and Tabu.spellCache[arg]) then
	-- 	return _.cloneTable(Tabu.spellCache[arg], false);
	-- end
	---print("####### spell info", arg, GetSpellInfo(arg))

	local name, rank, icon, castTime, minRange, maxRange, id = GetSpellInfo(arg);
	
	if (not name or not id) then return end

	local tbl = {  
		id = id,
		name = name,
		fullName = name,
		rank = rank,
		icon = icon,
		castTime = castTime,
		minRange = minRange,
		maxRange = maxRange,
	}
	
	local fullName, spellRank, maxRank, isMaxRank = _.GetRankedSpellInfo(id, name, shouldDebug);
	tbl.link = _.GetSpellLink(id, isMaxRank and tbl.name or fullName);
	tbl.fullName = fullName;
	tbl.spellRank = spellRank;
	tbl.maxRank = maxRank;
	tbl.isMaxRank = isMaxRank;

	if not isMaxRank and not not spellRank then
		tbl.name = fullName;
	end

	return tbl;
end

_.GetItemInfoTable = function(id)
	local arg = id;
	local name, link, rarity, level, minLevel, itemType, subType, stackCount, equipLoc, icon, sellPrice = GetItemInfo(id);
	if (type(id) ~= "number" and name) then
		id = GetItemInfoInstant(name);
	end
	local res = {
		id = id,
		name = name, 		
		link = link, 
		rarity = rarity, 
		level = level, 
		minLevel = minLevel, 
		type = itemType, 
		subType = subType, 
		stackCount = stackCount, 
		equipLoc = equipLoc, 
		icon = icon, 
		sellPrice = sellPrice
	}
	return res;
end

_.GetMacroInfoTable = function (id)
	if id == nil then return {}; end
	local name, icon, body, isLocal = GetMacroInfo(id)
	if type(id) ~= "number" then
		id = GetMacroIndexByName(id);
	end
	return {
		id = id,
		name = name,
		icon = icon,
		body = body,
		isLocal = isLocal
	}
end

_.buildFrameName = function(frameName)
	return A.Name .. "_" .. frameName;
end


local function GetSpellbookItemRankWord(index, book)
	local word;

	local spellName, rankName, spellId = GetSpellBookItemName(index, book);
	if (not spellName) then return nil, false end

	if (not _.isValue(rankName)) then return nil, true end;

	word = string.gsub(rankName, "%d+", "");
	if (not word) then return nil, true end
	rank = string.gsub(rankName, "%D", "");
	if (not _.isValue(rank)) then return nil, true end;

	local checkName = spellName.."("..word.." "..rank..")";
	local tested = GetSpellInfo(checkName);
	if (tested) then
		return word;
	else
		checkName = spellName.."("..rank.." "..word..")";
		tested = GetSpellInfo(checkName);
		if (tested) then
			-- reverse order
			return { word }
		end
	end

	return nil, true
end	

local function GetSpellbookRankWord(book)
	local index = 1;
	local word, lookMore = GetSpellbookItemRankWord(index, book);
	local escape = 0;
	if (_.isValue(word) or not lookMore) then return word end;
	while(not word) do
		index = index + 1;
		word, lookMore = GetSpellbookItemRankWord(index, book);
		if (_.isValue(word) or not lookMore) then return word end
		escape = escape + 1;
		if (escape > 300) then
			_.print("GetSpellbookRankWord will run forever. preventive escape");
			return;
		end
	end
end

local RANKEDNAME_TMPL = "%s(%s%s%s)";

local rankWordByLocales = {
	["ruRU"] = { "-й уровень", { "name", "rank", "empty", "word" } },
	["enGB"] = { "Rank", { "name", "word", "space", "rank" } },
	["enUS"] = { "Rank", { "name", "word", "space", "rank" } },
	["koKR"] = { "레벨", { "name", "rank", "space", "word" } }, -- REVERT ORDER: Shadow bolt(1 Rank),
	["zhTW"] = { "等级", { "name", "word", "space", "rank" } },
	["zhCN"] = { "等级", { "name", "word", "space", "rank" } },
	["esMX"] = { "Rango", { "name", "word", "space", "rank" } },
	["esES"] = { "Rango", { "name", "word", "space", "rank" } },
	["ptBR"] = { "Grau", { "name", "word", "space", "rank" } },
	["deDE"] = { "Rang", { "name", "word", "space", "rank" } },
	["frFR"] = { "Rang", { "name", "word", "space", "rank" } },
	["itIT"] = { "Rank", { "name", "word", "space", "rank" } }
}

local function DetectSpellRankWord()

	local locale = GetLocale();
	local word = rankWordByLocales[locale];

	if (_.isValue(word)) then
		return word;
	end

	word = GetSpellbookRankWord(BOOKTYPE_PET);
	if (_.isValue(word)) then
		return word;
	end

	return GetSpellbookRankWord(BOOKTYPE_SPELL);
end

local function GetWordNameArguments(schema, word, name, rank)

	local t = {
		word = word,
		name = name,
		rank = rank,
		space = " ",
		empty = ""
	};

	local res = {};

	for _k, _n in pairs(schema) do
		table.insert(res, t[_n]);
	end

	return res;
end

local WordPrototype = {
	template = RANKEDNAME_TMPL,
	GetName = function(self, name, rank)
		local args = GetWordNameArguments(self.schema, self.word, name, rank);
		return self.template:format(unpack(args));
	end
}

local function BuildWordRankedSpellName(self, name, rank)
end


local function BuildWord(word, schema)

	local res = {
		word = word,
		schema = schema,
	}
	Mixin(res, WordPrototype);

	return res;

end

_.GetSpellRankWord = function()
	
	if not Tabu.vars.spellRankWordDetected then
		Tabu.vars.spellRankWordDetected = true;
		local spellRank;
		local word = DetectSpellRankWord();
		if (type(word) == "table") then
			spellRank = BuildWord(unpack(word));
		elseif (_.isValue(word)) then
			spellRank = BuildWord(word, { "name", "word", "space", "rank" });
		end

		Tabu.vars.spellRankWord = spellRank;

		if (not _.isValue(Tabu.vars.spellRankWord)) then
			_.print("|cffff0000Tabu-Bars unable to detect special \"Spell Rank\" word for local |cffffff00"..GetLocale().."|r.");
		end

	end

	return Tabu.vars.spellRankWord;

	-- if (not _.isValue(Tabu.vars.spellRankWord)) then
	-- 	local word = DetectSpellRankWord();
	-- 	if (type(word) == "table") then
	-- 		spellRank = BuildWord(unpack(word));
	-- 		-- in case of table use revert order = rank goes first
	-- 		-- spellRank = {
	-- 		-- 	word = word[1],
	-- 		-- 	schema = word[2],
	-- 		-- 	text = RANKEDNAME_TMPL,
	-- 		-- 	GetName = function(self, name, rank)

	-- 		-- 		return self.text:format(name, rank, self.word);
	-- 		-- 	end
	-- 		-- }
	-- 	elseif (_.isValue(word)) then
	-- 		spellRank = BuildWord(word, { "name", "word", "space", "rank" });
	-- 		-- spellRank = {
	-- 		-- 	word = word,
	-- 		-- 	text = RANKEDNAME_TMPL,				
	-- 		-- 	GetName = function(self, name, rank)
	-- 		-- 		return self.text:format(name, self.word, rank);
	-- 		-- 	end
	-- 		-- }
	-- 	end
	-- 	Tabu.vars.spellRankWord = spellRank;
	-- end

	-- if (not _.isValue(Tabu.vars.spellRankWord)) then
	-- 	_.print("|cffff0000Tabu-Bars unable to detect special \"Spell Rank\" word for local |cffffff00"..GetLocale().."|r.");
	-- end

	-- return Tabu.vars.spellRankWord;
end



local getRankedSpellBindingKeyExtra = function (spell, actualId)
	local command = "SPELL ";
	local rank = 1;
	local tryRanks = true;
	while(tryRanks) do
		--local rankText = "(Уровень "..rank.. ")";
		local rankedName = _.GetRankedSpellName(spell, rank);
		if (rankedName == spell) then return end
		local ranked, _, _, _, _, _, checkId = GetSpellInfo(rankedName);
		if (not ranked) then return end;
		if (checkId == actualId) then
			return GetBindingKey(command..rankedName);
		end
		rank = rank + 1;
	end
end

_.getSpellBindingKey = function (spell, actualId)
	
	local key = getRankedSpellBindingKeyExtra(spell, actualId);
	if (key) then
		return key;
	end
	
	-- fallback to unranked spell binding
	return GetBindingKey("SPELL "..spell);

end


_.getSpellManaCost = function (arg)
	local res = GetSpellPowerCost(arg);
	if (not res) then return end
	for x, item in pairs(res) do
		if (item.name == "MANA") then
			return item.cost or 0;
		end
	end
end

_.getSpellManaCount = function (arg)
	local cost = _.getSpellManaCost(arg);
	if not cost or cost == 0 then return end
	local pm = UnitPower("player", 0);
	return math.floor(pm / cost);
end

_.getSpellCount = function(arg)
	local method = GetSpellCountFixed;
	if (not method) then
		method = GetSpellCount;
		--_.print("GetSpellCountFixed not installed, the default one instead");
	end
	local result = method(arg);
	if (result) then
		return result, "REAGENT"
	end
	local mana = _.getSpellManaCount(arg);
	return mana, "MANA";
end

_.getUnitAura = function(unit, arg, filter)
	local argType = type(arg);
	for index = 1, 100 do
		local name, rank, icon, count, debuffType, 
		duration, expirationTime, unitCaster, isStealable, 
		shouldConsolidate, spellId = UnitAura(unit, index, filter);

		if not name then
			return;
		end

		if (
			(argType == "string" and arg == name) 
			or
			(argType == "number" and spellId == arg)
	 	) then
			return name, rank, icon, count, debuffType, 
			duration, expirationTime, unitCaster, isStealable, 
			shouldConsolidate, spellId
		end
	end
end



_.round = function(number, digits)
	local pow;
	if (digits and digits > 0) then
		pow = 10 ^ digits;
		number = number * pow;
	end
	number = number % 1 >= 0.5 and math.ceil(number) or math.floor(number);
	if (pow) then
		number = number / pow;
	end
	return number;
end

_.getCooldown = function(_type, id)

	if (id and (_type == "spell" or _type == "Spell")) then
		return GetSpellCooldown(id);
	end

	if (id and type(id) == "number" and (_type == "item" or _type == "Item")) then
		return GetItemCooldown(id);
	end

end

_.isValue = function (arg)
	return arg ~= nil and arg ~= "";
end


_.startsWith = function(str, start)
	return str:sub(1, #start) == start;
end

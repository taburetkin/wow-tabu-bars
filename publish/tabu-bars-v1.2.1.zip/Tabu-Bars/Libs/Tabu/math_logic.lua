local A = Tabu:Addon(...);
--if A.Tabu__Initialized then return end
local _ = A.utils;

-- A.TabuInitMathLogic = function()
-- 	for key, fn in pairs(_) do
-- 		A.utils[key] = fn;
-- 	end
-- end

local A = Tabu:Addon(...);
if not A._InitializeTabu then
	return;
end
local Tabu = A.Tabu;
local _ = A.utils;
local CF = Tabu.ControlFrame;

Tabu.UI = {};
local UI = Tabu.UI;
UI.Core = {};

local Core = UI.Core;

local BuildName = function (name, root)
	if not name then return end
	if not root then
		return _.buildFrameName(name);
	end
	return root .. "_" .. name;
end

local defaultOptions = {};
local ensureOptions = function(options, ifEmpty)
	return options or ifEmpty or defaultOptions;
end

local frameApi = {}
frameApi = {

	calcHeight = function(frame)
		local children = { frame:GetChildren() };
		print('# calcHeight: ', #children);
		--if #children == 0 then return frame:GetHeight() end
		local height = 0;
		for ind, child in ipairs(children) do
			--if child
			height = height + child:GetHeight();
		end
		return height;
	end,

	updateHeight = function(frame)
		local h = frameApi.calcHeight(frame);
		frame:SetHeight(h);
		print('# updateHeight: ', h, frame:GetSize());
	end,

	setPoint = function(frame, point)
		if point then
			frame:SetPoint(unpack(point));
		end		
	end,

	setSize = function(frame, size)
		if size then
			frame:SetSize(unpack(size));
		end		
	end,

	setName = function(frame, name)
		if name then
			frame.name = name;
		end
	end,

	setup = function(frame, options)
		options = ensureOptions(options);
		frameApi.setPoint(frame, options.point);
		frameApi.setSize(frame, options.size);
		frameApi.setName(frame, options.name);
	end
}


local CreateCheckButton = function(parent, options)
	local frame = CreateFrame("CheckButton", nil, parent, "OptionsCheckButtonTemplate");
	local text = select(6, frame:GetRegions());
	frame.text = text;
	options = ensureOptions(options, {});
	if options.label then
		frame.text:SetText(options.label);
	end

	return frame;
end


local OptionsPanelMixin = {
	GetContentFrame = function(self)
		return self;
	end,
	CreateCheckBox = function(self, options)
		options = ensureOptions(options, {});
		local parent = self:GetContentFrame();
		local frame = CreateCheckButton(parent, options);
		frameApi.setPoint(frame, options.point or {"TOPLEFT", parent, "TOPLEFT", 0, 0});		
		return frame;
	end,
	UpdateHeight = function(self)
		local content = self:GetContentFrame();
		frameApi.updateHeight(content);
	end
}


local OptionsFrameMixin = {
	AddCategory = function(self, content, options)
		if not options then options = {} end;

		local frame = CreateFrame("Frame", nil, self.panelContainer);

		content:SetParent(frame);
		content:ClearAllPoints();
		content:SetPoint("TOPLEFT", 10, -10);
		content:SetPoint("BOTTOMRIGHT", -10, 10);

		if options.name then
			frame.name = options.name;
		end
		frame.parent = self.name;
		if not frame.name then
			frame.name = "Basic";
		end

		OptionsFrame_AddCategory(self, frame);
	end
}



UI.CreateOptionsFrame = function(name, options)
	
	options = ensureOptions(options);
	
	local frameName = BuildName(name);
	local frame = CreateFrame("Frame", frameName, nil, "OptionsFrameTemplate");
	
	frameApi.setup(frame, options);

	frame.headerText = _G[frameName .. "HeaderText"];
	frame.headerText:SetText(frame.name or "Options");

	CF.MakeMovable(frame);
	_.mixin(frame, OptionsFrameMixin);

	return frame;

end

UI.CreateOptionsPanel = function(options)
	options = ensureOptions(options);

	local frameName = BuildName(options.frameName, options.parentFrameName);
	--local frame = CreateFrame("Frame", frameName);
	local frame = CreateFrame("ScrollFrame", frameName, nil, "UIPanelScrollFrameTemplate");
	frameApi.setup(frame, options);
	-- scrollFrame:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -28, -26);
	-- scrollFrame:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 0, 36);
	
	
	local contentFrame = CreateFrame("Frame");
	contentFrame:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0);
	contentFrame:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -20, 0);
	frame:SetScrollChild(contentFrame);
	
	_.mixin(frame, OptionsPanelMixin);
	frame.GetContentFrame= function() 
		return contentFrame;
	end;

	-- local content = CreateFrame("Frame", BuildName(frameName and "Content", frameName), frame);
	-- content:SetPoint("TOPLEFT", frame, "TOPLEFT", 50, -50);
	-- content:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -50, -50);
	-- _.mixin(content, OptionsPanelMixin);

	return frame;
end

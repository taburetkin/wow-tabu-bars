local A, _, L = Tabu:Spread(...);
local buildedAt = "20.05.2021 15:22:11";
A.BUILD = {
    realm = "classic",
    version = 20501,
    maxVersion = 20600,
    nightly = false
}
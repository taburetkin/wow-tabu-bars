local A, _, L = Tabu:Spread(...);
local buildedAt = "19.05.2021 17:42:42";
A.BUILD = {
    realm = "classic",
    version = 20501,
    maxVersion = 20600,
    nightly = false
}
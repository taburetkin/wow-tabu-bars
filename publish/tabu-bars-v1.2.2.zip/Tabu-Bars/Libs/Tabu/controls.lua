--controls
local A = Tabu:Addon(...);
A.Tabu_controlsConfigs = {};
if A.Tabu__Initialized then 
	return;
end
local _ = A.utils;


if not Tabu.Controls then
	Tabu.Controls = {
		ControlBuilders = {},
		FontPath = "Fonts\\ARIALN.ttf";				
	}
end

if not Tabu.ControlFrame then
	Tabu.ControlFrame = {}
end

local L = A.localization.Get;
local ANCHORPOINTS = { "TOPLEFT", "TOPRIGHT", "BOTTOMLEFT", "BOTTOMRIGHT", "LEFT", "TOP", "RIGHT", "BOTTOM", "CENTER" };

local C = Tabu.Controls;


function C:SetControlBuilder(controlType, builder)
	self.ControlBuilders[controlType] = builder;
end

function C:GetControlBuilder(controlType)
	return self.ControlBuilders[controlType];
end

C.ControlFrameMixin = {
	ShouldSkip = function(self)
		if (type(self.context.shouldSkip) == "function") then			
			return self.context:shouldSkip(self:GetParent():GetEntity());
		end
	end,
	UpdateAnchor = function(self, previous, options)
		local settingsFrame = self:GetParent();
		self:SetWidth(settingsFrame:GetWidth() - 20);
		self:ClearAllPoints();
		if (not previous) then
			if (options and options.firstPoint) then
				self:SetPoint(unpack(options.firstPoint));
			else
				self:SetPoint("TOPLEFT", 10, -10);
			end
		else
			self:SetPoint("TOPLEFT", previous, "BOTTOMLEFT", 0, -5);
		end
	end,
	ApplyFormValue = function(self, previous, options)
		self:Hide();
		if (self:ShouldSkip()) then
			return;
		end

		self:UpdateAnchor(previous, options);
		
		local val = C.GetValueForControl(self.context, self:GetParent():GetEntity());
		if (val == nil and self.context.defaultValue) then
			val = self.context.defaultValue;
		end

		self:SetControlValue(val);
		self:Show();
	end,
	GetControlValue = function(self)
		return self.control:GetControlValue();
	end,
	SetControlValue = function(self, ...)
		return self.control:SetControlValue(...);
	end,
}

C.GetColorPickerValue = function()
	if (not ColorPickerFrame:IsShown()) then return end;
	local r, g, b = ColorPickerFrame:GetColorRGB();
	local a = OpacitySliderFrame:GetValue();
	return r, g, b, a
end


C.ShowColorPicker = function(changeCb, r, g, b, a)
	local cb = function()
		changeCb(C.GetColorPickerValue())
	end
	ColorPickerFrame:SetColorRGB(r,g,b);
	ColorPickerFrame.hasOpacity, ColorPickerFrame.opacity = (a ~= nil), a;
	ColorPickerFrame.previousValues = { r , g, b, a };
	ColorPickerFrame.func, ColorPickerFrame.opacityFunc = cb, cb;
	ColorPickerFrame.cancelFunc = function()
		changeCb(unpack(ColorPickerFrame.previousValues));
	end
	ColorPickerFrame:Hide(); -- Need to run the OnShow handler.
	ColorPickerFrame:Show();	
end


local function createEditFrameLabel(edit, label)
	edit.label = edit:CreateFontString(nil, "ARTWORK"); 
	edit.label:SetPoint("LEFT", 0, 0);
	edit.label:SetFont(C.FontPath, 16);
	edit.label:SetText(L(label));
end

local function createEditFrame(parent, context, FrameType)
	FrameType = FrameType or "Frame";
	local edit = CreateFrame(FrameType, nil, parent);
	edit:Hide();
	edit:SetHeight(40);
	createEditFrameLabel(edit, context.label);
	_.mixin(edit, C.ControlFrameMixin);
	return edit;
end
C.CreateEditFrame = createEditFrame;

local function hashDropdownInit(hash, control, shouldBeSkiped)
	local info;
	if (not shouldBeSkiped) then
		shouldBeSkiped = function() end;
	end
	control.GetValueText = function(self)
		return hash[self._value];
	end
	control.initialize = function(self)
		for value, label in pairs(hash) do
			local skip = shouldBeSkiped(value);
			if (not skip) then
				info = UIDropDownMenu_CreateInfo();
				info.text = label;
				info.arg1 = value;
				info.func = control.ClickHandler;
				info.checked = control:IsValueEqual(value)
			end
			UIDropDownMenu_AddButton(info, 1);
		end
	end
end
local function createDropDown(parent, make)
	local control = CreateFrame("Frame", nil, parent, "UIDropDownMenuTemplate");
	UIDropDownMenu_SetWidth(control, 145)
	control:SetSize(178, 30);
	control:SetPoint("RIGHT", parent, "RIGHT");	
	control.GetValueText = function(self)
		return self._value;
	end
	control.GetControlValue = function(self) 
		return self._value;
	end
	control.SetControlValue = function(self, value, text) 
		--value = NormalizeNil(value);
		self._value = value;
		if (not _.isValue(text)) then
			text = self:GetValueText();
		end
		UIDropDownMenu_SetText(self, text);
	end;
	control.IsValueEqual = function(self, ...)
		local selfValue = self:GetControlValue();
		local value = select(1, ...);
		if (selfValue == value) then return true end
		if (type(selfvalue) == "table") then
			for x,xv in pairs(selfvalue) do
				if (xv ~= select(x, ...)) then return false end
			end
			return true;
		end
		return false;
	end
	control.ClickHandler = function(self, arg1, arg2, checked)
		if (not arg2) then
			control:SetControlValue(arg1);
		else
			control:SetControlValue({ arg1, arg2 });
		end
	end	
	control.Refresh = function(self)
		make(control);	
	end
	make(control);
	return control;
end
C.CreateDropdownControl = createDropDown;


local function BooleanEditFrame(parent, context)
	local edit = createEditFrame(parent, context, "Button");
	edit:RegisterForClicks("AnyUp");
	edit:SetScript("OnClick", function(self)
		edit.control:Click();
	end);
	local control = CreateFrame("CheckButton", nil, edit, "ChatConfigCheckButtonTemplate");
	--control:SetFont(C.FontPath, 16);
	control:SetPoint("RIGHT", edit, "RIGHT", 0, 0);
	control:SetSize(30, 30);
	control.SetControlValue = function(self, checked)
		self:SetChecked(checked == true);
		self:SetValue(checked);
	end
	control:SetScript("OnClick", function(self) 
		local arg = self._value;
		arg = arg == true or arg == 1 or arg == "1";
		self._value = not arg;
	end);
	control.GetControlValue = function(self) 
		return self._value;
	end
	control.SetValue = function(self, arg) 
		if (arg ~= nil) then 
			arg = arg == true or arg == 1 or arg == "1";
			self._value = arg;
		else
			self._value = nil;
		end
	end
	edit.control = control;
	return edit;
end
C:SetControlBuilder("boolean", BooleanEditFrame);


local function makeBitwiseDropdown(control, context)
	local info;
	local data = {};
	local labels = {};
	
	for label, value in pairs(context.sourceValues) do
		table.insert(data, { label = label, value = value });
		labels[tostring(value)] = label;
	end
	table.sort(data, function(a,b) 
		if (a.value == -1 or b.value == -1) then
			return a.value > b.value;
		else
			return a.value < b.value;
		end
	end);
	control.GetValueText = function(self)
		local text = "";
		local selfVal = 0;
		if (_.isValue(self._value)) then
			selfVal = self._value;
		end

		if (selfVal == 0) then
			return labels["0"];
		end
		if (selfVal == -1) then
			return labels["-1"];
		end

		for txtval, label in pairs(labels) do
			local numval = tonumber(txtval);
			local bitand = bit.band(selfVal, numval);
			if (numval > 0 and bitand == numval) then
				if (_.isValue(text)) then
					text = text .. ", ";
				end
				text = text .. label;
			end
		end
		return text;
	end	
	control.ClickHandler = function(self, arg1, arg2, checked)
		local current = control:GetControlValue();

		if (arg1 == 0 or arg1 == -1) then
			control:SetControlValue(arg1);
			ToggleDropDownMenu(1, arg1, control);
			ToggleDropDownMenu(1, arg1, control);
			return;
		end
		local reinit = false;
		if (current == nil or current == -1 or current == 0) then
			reinit = true;
			current = 0;
		end
		if (bit.band(current, arg1) == arg1) then
			current = bit.bxor(current, arg1);
		else
			current = bit.bor(current, arg1);
		end
		control:SetControlValue(current);
		if (reinit == true) then

			ToggleDropDownMenu(1, current, control);
			ToggleDropDownMenu(1, current, control);
		end
	end	
	control.IsValueEqual = function(self, arg1)
		local current = control:GetControlValue();		
		current = current or 0;
		if (current == 0 or current == -1 or arg1 == 0 or arg1 == -1) then
			return arg1 == current;
		end
		return bit.band(current, arg1) == arg1;
	end
	control.initialize = function(self)
		for k, h in ipairs(data) do

			info = UIDropDownMenu_CreateInfo();
			info.isNotRadio = h.value > 0;
			info.text = h.label;
			info.arg1 = h.value;
			--info.colorCode = "|cffff0000";
			info.keepShownOnClick = true;
			info.func = control.ClickHandler;
			info.checked = control:IsValueEqual(h.value)

			UIDropDownMenu_AddButton(info, 1);
		end
	end	
end
local function BitwiseMaskEditFrame(parent, context)
	local edit = createEditFrame(parent, context, "Button");
	edit.control = createDropDown(edit, function(control) return makeBitwiseDropdown(control, context) end);
	return edit;
end
C:SetControlBuilder("bitwisemask", BitwiseMaskEditFrame);

local function NormalizeNil(arg)
	if (arg == '[nil]') then
		return nil
	else
		return arg
	end
end

--#region NUMBER
local function NumberEditFrame(parent, context)

	local edit = createEditFrame(parent, context);

	local control = CreateFrame("EditBox", nil, edit, "InputBoxTemplate");
	control:SetFont(C.FontPath, 16);
	control:SetPoint("RIGHT", edit, "RIGHT", 0, 0);
	control:SetSize(90, 30);
	control:SetAutoFocus(false);
	control.SetControlValue = function(self, text)
		--text = NormalizeNil(text);
		local val = tostring(text or "");
		if (context.beforeValueSet) then
			val = context.beforeValueSet(val);
		end
		self:SetText(val);
	end
	control.GetControlValue = function(self)
		local text = self:GetText();
		if (not _.isValue(text)) then return "" end;
		local value = self:GetNumber();
		if (not value) then
			return "";
		end
		return value;
	end

	edit.control = control;

	return edit;
end
C:SetControlBuilder("number", NumberEditFrame);
--#endregion NUMBER

--#region POINT
local function makePointDropdown(control, shouldBeSkiped)
	local info;
	if (not shouldBeSkiped) then
		shouldBeSkiped = function() end;
	end
	control.initialize = function(self)
		for _, point in pairs(ANCHORPOINTS) do
			local skip = shouldBeSkiped(point);
			if (not skip) then
				info = UIDropDownMenu_CreateInfo();
				info.text = point;
				info.arg1 = point;
				info.func = control.ClickHandler;
				info.checked = control:IsValueEqual(point)
			end
			UIDropDownMenu_AddButton(info, 1);
		end
	end
end
local function PointEditFrame(parent, context)
	local edit = createEditFrame(parent, context);	
	edit.control = createDropDown(edit, makePointDropdown);
	return edit;
end
C:SetControlBuilder("point", PointEditFrame);
--#endregion


--#region COLOR
local function ColorEditFrame(parent, context)
	local edit = createEditFrame(parent, context);

	local clr = CreateFrame("Button", nil, edit);
	clr:SetPoint("RIGHT", edit, "RIGHT", -2, 0);
	clr:SetSize(90, 40);

	local t = clr:CreateTexture(nil, "BACKGROUND");
	t:SetAllPoints();
	clr.bg = t;
	
	clr.text = clr:CreateFontString(nil, "OVERLAY");
	clr.text:SetFont("FONTS\\ARIALN.ttf", 10, "THICKOUTLINE");
	clr.text:SetPoint("TOPLEFT", clr, "TOPLEFT", 1, -1);
	clr.text:SetJustifyH("LEFT");

	local frm = "R: %s\nG: %s\nB: %s\nA: %s";
	clr.text.UpdateText = function(self, r, g, b, a)
		r = r and _.round(r, 5) or "";
		g = g and _.round(g, 5) or "";
		b = b and _.round(b, 5) or "";
		a = a and _.round(a, 5) or "";
		self:SetText(string.format(frm, r,g,b,a));
	end


	clr:SetScript("OnClick", function() 
		Tabu.Controls.ShowColorPicker(function(r,g,b,a) 
			if (r and g and b) then
				edit:SetControlValue({r,g,b,a});
			end
		end, unpack(edit:GetControlValue() or {}))
	end)
	
	edit.control = clr;

	
	edit.GetControlValue = function(self)
		return self._controlValue;
	end
	edit.SetControlValue = function(self, value)
		-- if (value == nil) then
		-- 	value = { 0, 0, 0, .8 };
		-- end
		self._controlValue = value;
		value = value or {0,0,0,0};
		self.control.bg:SetColorTexture(unpack(value));
		self.control.text:UpdateText(unpack(value));
	end	

	return edit;
end
C:SetControlBuilder("color", ColorEditFrame);
--#endregion


--#region FONT edit
local function makeFontDropdown(parent, context)
	local hash;
	local varType = type(context.sourceValues);
	if (varType == 'function') then
		hash = context.sourceValues();
	elseif (varType == 'table') then
		hash = context.sourceValues;
	else
		hash = {};
	end
	return function(control, shouldBeSkiped)
		hashDropdownInit(hash, control, shouldBeSkiped);
	end
end
local function FontEditFrame(parent, context)
	local edit = createEditFrame(parent, context);
	edit.control = createDropDown(edit, makeFontDropdown(parent, context));
	return edit;
end
C:SetControlBuilder("font", FontEditFrame);
--#endregion



C.GetValueForControl = function (cntx, entity)
	if (type(cntx.getEntityValue) == "function") then
		return cntx.getEntityValue(entity);
	end
	if (type(cntx.key) == "table") then
		local res = {};
		for _, key in pairs(cntx.key) do
			local v = entity[key];
			table.insert(res, v);
		end
		return res;
	else
		return entity[cntx.key];
	end
end


C.GetFormControlValue = function(control, resultTable)
	resultTable = resultTable or {};
	if (not control or not control.controlFrame or not control.controlFrame:IsShown()) then 
		return resultTable;
	end;
	local value = control.controlFrame:GetControlValue();

	if (type(control.key) == "table") then
		if (type(value) ~= "table") then
			value = { value };
		end
		for ind, key in pairs(control.key) do
			resultTable[key] = value[ind];
		end
	else
		resultTable[control.key] = value;
	end

	return resultTable;
end

C.GetFormValue = function(controls)
	local res = {}
	for x, control in pairs(controls) do
		C.GetFormControlValue(control, res);
	end
	return res;
end

C.ApplyFormValuesToEntity = function(entity, values)
	for k,v in pairs(values) do
		entity[k] = v;
	end
end







C.BuildControlFrame = function(parentFrame, context)
	
	local controlType = context.control;
	local controlFrame;

	

	local builder = C:GetControlBuilder(controlType);
	
	if (type(builder) ~= "function") then
		error("Unknown control builder: ".. controlType);
	end

	controlFrame = builder(parentFrame, context);
	if (not controlFrame) then return end;
	

	controlFrame.context = context;
	return controlFrame;
end


-- local configs = {};

-- local configFrames = {};
-- local configFramesControls = {};
-- local configFramesMixins = {};
-- local configFramesSetups = {};

C.ConfigFrameMixin = {
	SetControls = function(self, controls)
		self.controls = controls;
	end,

	GetControls = function(self) 
		return self.controls;
	end,

	GetEntity = function(self) 
		return self.entity;
	end,

	SetEntity = function(self, entity) 
		self.entity = entity;
	end,

	GetValue = function(self)
		local controls = self:GetControls();
		return C.GetFormValue(controls);
	end,

	AfterApplyValues = function(self) end, -- MUST BE OVERRIDED

	ApplyFormValues = function(self)
		local values = self:GetValue();
		local entity = self:GetEntity();
		if type(self.BeforeApplyValues) == 'function' then
			self:BeforeApplyValues(values, entity);
		end
		C.ApplyFormValuesToEntity(entity, values);
		if (type(self.OwnAfterApply) == 'function') then
			self:OwnAfterApply();
		else
			self:AfterApplyValues();
		end
	end,

	InitForm = function(self, entity, afterApply)
		self.OwnAfterApply = afterApply;
		self:SetEntity(entity);
		self:UpdateFrameValues(); --applyValuesToConfigFrame(self);
	end,
	GetControlsParent = function(self)
		return self._controlsParent or self;
	end,
	SetControlsParent = function(frame, parent)
		frame._controlsParent = parent;
		parent.GetEntity = function()
			return frame:GetEntity();
		end
	end,	
	UpdateFrameValues = function(frame)
		local parent = frame:GetControlsParent();
		local controls = frame:GetControls();
		local previousControlFrame;
		local firstPoint = { "TOPLEFT", 10, 0 };
		frame.childrenHeight = 0;
		local count = 0;
		for index, control in pairs(controls) do
			--_.print("::", frame.formName, index);
			if (not control.id) then
				control.id = frame.formName .. "_CfgProp_"..index;
			end
			if (not control.controlFrame) then
				control.controlFrame = C.BuildControlFrame(parent, control);
			end
			if (control.controlFrame) then
				control.controlFrame:ApplyFormValue(previousControlFrame, { firstPoint = firstPoint });
				if (control.controlFrame:IsShown()) then
					previousControlFrame = control.controlFrame;
					frame.childrenHeight = frame.childrenHeight + control.controlFrame:GetHeight();
					count = count + 1;
				end
			end
		end
		parent:SetHeight(frame.childrenHeight + (count - 1)*5);
		frame:Refresh();
	end,
	Refresh = function(self)
		local content = self:GetControlsParent();
		if (content == self) then return end
		local addHeight = 80;
		local maxUnscroll = 400 + addHeight;
		local height = content:GetHeight();
		local mainFrameHeight = height + addHeight;
		
		if (mainFrameHeight > maxUnscroll) then
			self:SetHeight(maxUnscroll);
		else
			self:SetHeight(mainFrameHeight);
		end
	end,
	TabClicked = function(self, tabButton)
		if (self._currentTab) then 
			self._currentTab:MakeInActive();
		end;
		self._currentTab = tabButton;
	end
}


local function setupConfigFrame(frame, setup, name)
	_.mixin(frame, C.ConfigFrameMixin);
	frame:SetControls(setup.controls);
	frame.formName = name;
	local mixin = setup.mixin; --configFramesMixins[name];
	if (type(mixin) == "table") then
		_.mixin(frame, mixin);
	end
	local setup = setup.setup; --configFramesSetups[name];
	if (type(setup) == "function") then
		setup(frame, name);
	end
end

local function setupConfigTabs(frame, tabs)
	if (not tabs) then return end;
	local prevTab;
	if (not frame.tabs) then
		frame.tabs = {};
	end
	for i, tab in ipairs(tabs) do		
		local button = CreateFrame("Button", nil, frame);		
		button:RegisterForClicks("AnyUp");
		--button:("GameFontNormalSmall")
		local fs = button:CreateFontString(nil, "OVERLAY");
		fs:SetFont("FONTS\\ARIALN.ttf", 10);
		fs:SetText(L(tab.name));
		fs:SetPoint('LEFT', button, 'LEFT', 10, 0);
		fs:SetTextColor(1,1,1,1);
		local width = fs:GetStringWidth();
		button:SetFontString(fs);
		button:SetSize(width+20, 26);

		button.group = tab.group;
		table.insert(frame.tabs, button);

		button.bg = _.createColorTexture(button, 0, 0, 0, 0.5, "BACKGROUND");
		button.hlbg = _.createColorTexture(button, 1, 1, 1, 0.1, "BORDER");
		button.hlbg:Hide();
		button.chbg = _.createColorTexture(button, .25,.25,.25,.9, "ARTWORK");
		button.chbg:Hide();

		button.GetChecked = function(self)
			return self._checked == true;
		end
		button.SetChecked = function(self, value)
			self._checked = (value == true);
		end
		button.MakeActive = function(self)
			self:SetChecked(true);
			self.chbg:Show();
		end
		button.MakeInActive = function(self)
			self:SetChecked(false);
			self.chbg:Hide();
		end

		button.OnEnter = function(self) self:ShowHighlightBg(); end;
		button.OnLeave = function(self) self:HideHighlightBg(); end;
		button.OnClick = function(self) 
			local che = self:GetChecked();
			if (che) then return end;
			self:GetParent():TabClicked(self);
			self:MakeActive();
		end
		button.ShowCheckedBg = function(self) self.chbg:Show(); end
		button.HideCheckedBg = function(self) self.chbg:Hide(); end
		button.ShowHighlightBg = function(self) self.hlbg:Show(); end
		button.HideHighlightBg = function(self) self.hlbg:Hide(); end		

		button:SetScript("OnClick", button.OnClick)
		button:SetScript("OnEnter", button.OnEnter)
		button:SetScript("OnLeave", button.OnLeave)



		--button:SetNormalTextColor(1,.5,.5,1);

		--button.NormalFontObject:SetFont("FONTS\\ARIALN.ttf", 10);
		--_.createColorTexture(button, 0,0,0,1);


		-- local tx = button:CreateTexture(nil, "BACKGROUND");
		-- tx:SetColorTexture(0,0,0, 1);
		-- tx:SetAllPoints();
		-- button:SetNormalTexture(tx);

		-- tx = button:CreateTexture(nil, "BACKGROUND");
		-- tx:SetColorTexture(.1, .1, .1, 1);
		-- tx:SetAllPoints();
		-- button:SetHighlightTexture(tx, "BLEND");

		-- tx = button:CreateTexture(nil, "BACKGROUND");
		-- tx:SetColorTexture(.2, .2, .2, 1);
		-- tx:SetAllPoints();
		-- button:SetCheckedTexture(tx, "BLEND");

		-- button:SetScript("OnEnter", function(self) 
		-- 	C_Timer.After(.3, function() 
		-- 		deprint('#', self:GetButtonState());
		-- 	end)
		-- end)
		--button:SetScript("OnLeave", function(self) self:SetButtonState("NORMAL", false); end);


		if (not prevTab) then
			button:SetPoint("BOTTOMLEFT", frame, "TOPLEFT", 10, 0);
		else
			button:SetPoint("BOTTOMLEFT", prevTab, "BOTTOMRIGHT", 2, 0);
		end
		prevTab = button;
	end
end

C.CreateConfigFrame = function(A, name, setup)

	if (type(A) ~= "table") then
		error('Unspecified Addon');
	end

	local bg = setup.bg or { .15,.15,.15,.9,"BACKGROUND" };

	local frame = setup.frame or _.createDialogFrame({
		name = A.Name .. "_" .. name .. "Frame",
		bg = bg,
		border = setup.border ~= nil
	});


	frame:SetFrameLevel(UIParent:GetFrameLevel() + 100);
	frame:SetPoint("CENTER");
	frame:SetSize(450, 300);

	--setupConfigTabs(frame, setup.tabs);

	setupConfigFrame(frame, setup, name);


	local scrollFrame = CreateFrame("ScrollFrame", "$parent_Scroll", frame, "UIPanelScrollFrameTemplate");
	scrollFrame:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -28, -26);
	scrollFrame:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 0, 36);


	local contentFrame = CreateFrame("Frame");
	contentFrame:SetPoint("TOPLEFT", scrollFrame, "TOPLEFT", 0, 0);
	contentFrame:SetWidth(scrollFrame:GetWidth());
	scrollFrame:SetScrollChild(contentFrame);

	frame:SetControlsParent(contentFrame);
	frame.scroll = scrollFrame;

	local save = CreateFrame("Button", nil, frame, "OptionsButtonTemplate");
	save:SetText(L("Save Changes"));
	save:SetSize(150, 26);
	save:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 5, 5);
	save:SetScript("OnClick", function(self) 
		frame:ApplyFormValues();
	end);

	local close = CreateFrame("Button", nil, frame, "OptionsButtonTemplate");
	close:SetText(L("Close"));
	close:SetSize(90, 26);
	close:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -5, 5);
	close:SetScript("OnClick", function() frame:Hide() end);

	frame:Hide();

	return frame;
end

C.GetConfigFrame = function(A, name, entity, afterApply)
	if (type(A) ~= "table") then
		error('Unspecified Addon');
	end

	local setup = A.Tabu_controlsConfigs[name];
	if (not setup) then
		error("Not registered config settings: ".. (name or ''));
	end

	if (not setup.frame) then
		setup.frame = C.CreateConfigFrame(A, name, setup);
	end

	if entity then
		setup.frame:InitForm(entity, afterApply);
	end

	return setup.frame;
	-- if (not configFrames[name]) then
	-- 	local controls = configFramesControls[name];
	-- 	configFrames[name] = C.CreateConfigFrame(name, controls);
	-- end
	-- return configFrames[name];
end

C.ShowSettings = function(A, name, entity, afterApply)
	if (not entity) then return end
	local frame = C.GetConfigFrame(A, name);
	frame:InitForm(entity, afterApply);
	C_Timer.After(.1, function() 
		frame:Show();
	end)
end

C.RegisterSettings = function(A, name, data)
	if (type(A) ~= "table") then
		error('Unspecified Addon');
	end
	A.Tabu_controlsConfigs[name] = _.cloneTable(data, true);
	--_.print('# settings', name);
	-- configFramesControls[name] = data.controls;
	-- configFramesMixins[name] = data.mixin;
	-- configFramesSetups[name] = data.setup;
end


local CF = Tabu.ControlFrame;

CF.MakeMovable = function(frame, triggerFrame, afterStart, afterStop)
	frame:EnableMouse(true);
	frame:SetMovable(true);
	
	triggerFrame = triggerFrame or frame;
	triggerFrame.movableFrame = frame;
	triggerFrame:RegisterForDrag("LeftButton")
	triggerFrame:SetScript("OnDragStart", function(self) 

		local mframe = self.movableFrame;
		if not mframe.isLocked then
			mframe:StartMoving()
		end
		if type(afterStart) == "function" then
			afterStart(frame, triggerFrame);
		end
	end)
	
	triggerFrame:SetScript("OnDragStop", function(self) 
		local mframe = self.movableFrame;
		mframe:StopMovingOrSizing();
		if type(mframe.AfterStopMovingOrSizing) == "function" then
			mframe:AfterStopMovingOrSizing();
		end
		if type(afterStop) == "function" then
			afterStop(frame, triggerFrame);
		end
	end)
	
end

CF.MakeClosable = function(frame)
	local btn = CreateFrame("Button", nil, frame);
	btn:SetSize(32,32);
	btn:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -3, -3);
	btn:SetNormalTexture([[Interface\Buttons\UI-Panel-MinimizeButton-Up]]);
	btn:SetPushedTexture([[Interface\Buttons\UI-Panel-MinimizeButton-Down]]);
	btn:SetHighlightTexture([[Interface\Buttons\UI-Panel-MinimizeButton-Highlight]]);
	btn:SetScript("OnClick", function(self) self:GetParent():Hide() end);
	frame.closeButton = btn;
end

CF.ApplyOptionsTheme = function (frame)
	frame.bg = _.createColorTexture(frame, 0,0,0, .3,"BACKGROUND");
	frame.border = _.setFrameBorder(frame, 0, 0, 0, 1);
end


CF.CreateScrollFrame = function(parent, name, insetBar)
	local parentName = parent:GetName();
	if not _.isValue(parentName) then
		error("ScrollFrame's Parent must have a name");
	end
	name = name or "ScrollFrame";
	name = "$parent_"..name;
	-- local contentName;
	-- if name then
	-- 	name = "$parent_"..name;
	-- 	contentName = name .. "_Content";
	-- end
	local scroll = CreateFrame("ScrollFrame", name, parent, "OptionsBoxTemplate, UIPanelScrollFrameTemplate");
	local sbar = _G[scroll:GetName().."ScrollBar"];
	scroll.scrollBar = sbar;
	if insetBar then
		scroll.scrollBar:ClearAllPoints();
		scroll.scrollBar:SetPoint("TOPRIGHT", scroll, "TOPRIGHT", -6, -22);
		scroll.scrollBar:SetPoint("BOTTOMRIGHT", scroll, "BOTTOMRIGHT", -6, 22);
	end
	--local content = CreateFrame("Frame");
	--scroll:SetScrollChild(content);
	--content:SetAllPoints();
	--content:SetPoint("TOPLEFT", scrollFrame, "TOPLEFT", 0, 0);
	--content:SetWidth(scrollFrame:GetWidth());

	scroll.bg = _.createColorTexture(scroll, 0,0,0, .3,"BACKGROUND");
	--content.bg = _.createColorTexture(content, .5,0,0, .3,"BACKGROUND");

	-- scroll.SetFrameWidth = function(self, width)
	-- 	self:SetWidth(width);
	-- 	self:GetScrollChild():SetWidth(width)
	-- end

	return scroll --, content;
end


CF.CreateTwoSidedOptionsFrame = function(name)
	if not name then
		error("Name must be provided")
	end
	local frame = CreateFrame("Frame", name, UIParent);
	--CF.MakeMovable(frame);
	--CF.MakeClosable(frame);
	CF.ApplyOptionsTheme(frame);

	--local leftScroll, leftContent = CF.CreateScrollFrame(frame, "LeftSide", true);
	local leftScroll = CreateFrame("Frame", "$parent_Left", frame, "OptionsFrameListTemplate");
	leftScroll:SetPoint("TOPLEFT", frame, "TOPLEFT", 10, -20);
	leftScroll:SetSize(200, 350);
	-- frame.leftScroll = leftScroll;
	-- frame.leftContent = leftContent;


	-- local rightScroll, rightContent = CF.CreateScrollFrame(frame, "RightSide");
	-- frame.rightScroll = rightScroll;
	-- frame.rightContent = rightContent;

	-- rightScroll:SetPoint("TOPLEFT", leftScroll, "TOPRIGHT", 0, -20);
	-- rightScroll:SetSize(200, 350);

	-- local third = CF.CreateScrollFrame(frame, "Third");
	-- third:SetPoint("TOPLEFT", rightScroll, "TOPRIGHT", 0, -20);
	-- third:SetSize(200, 350);

	return frame;
end



if not Tabu.Gui then
	Tabu.UI = {}
end

local ui = Tabu.UI;



ui.Create = function(parentFrame)
	local control = C.BuildControlFrame(parentFrame, options);
	control:SetPoint(unselect(anchor));
	return control;
end

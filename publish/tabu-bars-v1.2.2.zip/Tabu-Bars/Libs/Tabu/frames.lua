local A = Tabu:Addon(...);
--if A.Tabu__Initialized then return end
local _ = A.utils;

-- A.TabuInitFrames = function()
-- 	for key, fn in pairs(_) do
-- 		A.utils[key] = fn;
-- 	end
-- end

_.createColorTexture = function(frame, r, g, b, a, layer, inherits, sublayer)
	local t = frame:CreateTexture(nil, layer, inherits, sublayer);
	t:SetAllPoints();
	t:SetColorTexture(r, g, b, a);
	return t;
end

_.setFrameBorder = function (frame, r, g, b, a, size, outer)
	size = size or 1;
	local insets;
	if (outer) then
		insets = { left = -size, right = -size, top = -size, bottom = -size };
	end
	if (r ~= nil) then
		frame:SetBackdrop({
			edgeFile = [[Interface\Buttons\WHITE8x8]],
			edgeSize = size,
			insets = insets
		});
		frame:SetBackdropBorderColor(r,g,b,a);
	else
		frame:SetBackdrop(nil);		
	end
end

local defOptions = {
	bg = { 0, 0, 0, .8, "BACKGROUND" },
	border = { 0, 0, 0, 1 }
}

_.createDialogFrame = function(opts, frameType, frameName, frameParent, alsoInherits)

	local options = _.cloneTable(defOptions);
	_.mixin(options, opts or {});

	--local inherits = _.buildFrameName("DialogTemplate");

	-- if not _G[inherits] then
	-- 	_.print("DialogTemplate not registered", inherits);
	-- 	--inherits = nil;
	-- end

	-- if (alsoInherits) then
	-- 	inherits = inherits .. ", " .. alsoInherits;
	-- end

	frameType = frameType or "Frame";
	frameParent = frameParent or UIParent;

	frameName = frameName or options.name;

	alsoInherits = A.fixedBackdropTemplate(alsoInherits);
	--local fr = CreateFrame(frameType, frameName, frameParent, inherits);
	local fr = CreateFrame(frameType, frameName, frameParent, alsoInherits);
	

	if (options.bg) then
		fr.bg = _.createColorTexture(fr, unpack(options.bg));
	end

	if (options.border) then
		fr.border = _.setFrameBorder(fr, unpack(options.border));
	end

	return fr;
end




local function setButtonTexture(tex, btn, offset, path)
	offset = offset or 0;
	if path then
		tex:SetTexture(path);
	end
	tex:ClearAllPoints();
	tex:SetPoint("TOPLEFT", btn, "TOPLEFT", offset, -offset);
	tex:SetPoint("BOTTOMRIGHT", btn, "BOTTOMRIGHT", -offset, offset);

end

_.createIconButton = function(iconPath, btn, offset)
	local tex;
	offset = offset or 0;
	btn = btn or CreateFrame("Button");

	btn:SetNormalTexture("Interface\\Buttons\\UI-Quickslot2");
	tex = btn:GetNormalTexture();
	setButtonTexture(tex, btn, offset);


	tex = btn:CreateTexture(nil, "ARTWORK");
	setButtonTexture(tex, btn, offset, iconPath);


	btn:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square");
	tex = btn:GetHighlightTexture();
	setButtonTexture(tex, btn, offset);
	
	btn:SetPushedTexture("Interface\\Buttons\\UI-Quickslot-Depress");
	tex = btn:GetPushedTexture();
	tex:ClearAllPoints();
	tex:SetAllPoints();
	tex:SetBlendMode("ADD");
	--setButtonTexture(tex, btn, offset);

end


if A.Tabu__Initialized then return end

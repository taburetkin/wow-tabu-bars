local A = Tabu:Addon(...);
local _ = A.utils;

_.createColorTexture = function(frame, r, g, b, a, layer, inherits, sublayer)
	local t = frame:CreateTexture(nil, layer, inherits, sublayer);
	t:SetAllPoints();
	t:SetColorTexture(r, g, b, a);
	return t;
end

_.setFrameBorder = function (frame, r, g, b, a, size, outer)
	size = size or 1;
	local insets;
	if (outer) then
		insets = { left = -size, right = -size, top = -size, bottom = -size }
	end
	if (r ~= nil) then
		frame:SetBackdrop({
			edgeFile = [[Interface\Buttons\WHITE8x8]],
			edgeSize = size,
			insets = insets
		});
		frame:SetBackdropBorderColor(r,g,b,a);
	else
		frame:SetBackdrop(nil);		
	end
end

local defOptions = {
	bg = { 0, 0, 0, .8, "BACKGROUND" },
	border = { 0, 0, 0, 1 }
}
_.createDialogFrame = function(opts, frameType, frameName, frameParent, alsoInherits)

	local options = _.cloneTable(defOptions);
	_.mixin(options, opts or {});

	local inherits = "Tabu_DialogTemplate";
	if (alsoInherits) then
		inherits = inherits .. ", " .. alsoInherits;
	end
	frameType = frameType or "Frame";
	frameParent = frameParent or UIParent;

	frameName = frameName or options.name;

	local fr = CreateFrame(frameType, frameName, frameParent, inherits);
	if (options.bg) then
		fr.bg = _.createColorTexture(fr, unpack(options.bg));
	end
	if (options.border) then
		fr.border = _.setFrameBorder(fr, unpack(options.border));
	end
	return fr;
end

local A = Tabu:Addon(...);
local _ = A.utils;

_.updateTable = function (dst, src, debug)
	if (type(dst) ~= "table" or type(src) ~= "table") then
		_.print("One of Mixin arguments is not a table", debug);
		return;
	end
	for key, val in pairs(src) do
		dst[key] = src[key]
	end
end
_.mixin = _.updateTable;

_.cloneTable = function(tbl, notDeep, ...)
	if (type(tbl) ~= "table") then return end;
	local res = {};
	local index = 1;
	local isArray = false;
	local keyed = select("#", ...) > 0;
	local keys = { ... };
	local data = tbl;
	if (keyed == true) then
		data = keys;
	end
	for k,v in pairs(data) do
		local value;
		if (keyed) then
			value = tbl[v];
		else
			value = v;
		end

		if (type(value) == "table" and notDeep ~= true) then
			value = _.cloneTable(value);
		end

		if (index == 1) then
			if (keyed) then
				isArray = type(v) == "number";
			else
				isArray = k == 1;
			end
		end

		if (isArray) then
			table.insert(res, value);
		else
			local key = keyed and v or k;
			res[key] = value;
		end

		index = index + 1;
	end
	return res;
end

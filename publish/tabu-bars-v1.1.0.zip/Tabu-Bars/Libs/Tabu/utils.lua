local A = Tabu:Addon(...);
local _ = A.utils;

_.print = function(...)
	print("|cffff8000"..A.Name.."|r", ...);
end



local currentId = 0;
local setUniqueId = function(id, shouldNotCache)
	currentId = id;
	if (not shouldNotCache) then
		local cache = A:GetCache();
		cache.uniqueidentifier = id;
	end
end

_.initializeUniqueId = function()
	local cache = A:GetCache();
	setUniqueId(cache.uniqueidentifier or 0, true);
end


_.updateUniqueId = function(item)
	if (item and item.rawId > currentId) then
		currentId = id;
	end
end

_.uniqueId = function(prefix)
	local newid = currentId + 1;

	setUniqueId(newid);

	if (prefix) then
		newid = prefix..newid;
	end
	return newid;
end

_.setId = function(item, prefix)
	item.rawId = _.uniqueId();
	if (prefix) then
		item.id = prefix .. item.rawId;
	else
		item.id = item.rawId;
	end
end




local spellLinkTemplate = "|cff71d5ff|Hspell:%s|h[%s]|h|r";
_.GetSpellLink = function(name)
	local sname, __, __, __, __, __, sid = GetSpellInfo(name);

	return string.format(spellLinkTemplate, sid, sname);
end


_.GetSpellInfoTable = function(arg)
	local name, rank, icon, castTime, minRange, maxRange, id = GetSpellInfo(arg);
	local tbl = {  
		id = id,
		name = name,
		rank = rank,
		icon = icon,
		castTime = castTime,
		minRange = minRange,
		maxRange = maxRange,
		link = _.GetSpellLink(id)
	}
	return tbl;
end

_.GetItemInfoTable = function(id)
	local arg = id;
	local name, link, rarity, level, minLevel, itemType, subType, stackCount, equipLoc, icon, sellPrice = GetItemInfo(id);
	if (type(id) ~= "number" and name) then
		id = GetItemInfoInstant(name);
	end
	local res = {
		id = id,
		name = name, 		
		link = link, 
		rarity = rarity, 
		level = level, 
		minLevel = minLevel, 
		type = itemType, 
		subType = subType, 
		stackCount = stackCount, 
		equipLoc = equipLoc, 
		icon = icon, 
		sellPrice = sellPrice
	}
	return res;
end

_.GetMacroInfoTable = function (id)
	local name, icon, body, isLocal = GetMacroInfo(id)
	return {
		id = id,
		name = name,
		icon = icon,
		body,
		isLocal = isLocal
	}
end

_.buildFrameName = function(frameName)
	return A.Name .. "_" .. frameName;
end



local getRankedSpellBindingKeyExtra = function (spell, actualId)
	local command = "SPELL "..spell;
	local rank = 1;
	local tryRanks = true;
	while(tryRanks) do
		local rankText = "(Уровень "..rank.. ")";
		local ranked, _, _, _, _, _, checkId = GetSpellInfo(spell..rankText);
		if (not ranked) then return end;
		if (checkId == actualId) then
			return GetBindingKey(command..rankText);
		end
		rank = rank + 1;
	end
end

_.getSpellBindingKey = function (spell, actualId)
	local command = "SPELL "..spell;
	local key;

	key = getRankedSpellBindingKeyExtra(spell, actualId);
	if (key) then
		return key;
	end

	return GetBindingKey(command);

end

_.getSpellCount = function(arg)
	local method = GetSpellCountFixed;
	if (not method) then
		method = GetSpellCount;
		_.print("GetSpellCountFixed not installed, the default one instead");
	end
	local result = method(arg);
	if (result) then
		return result, "REAGENT"
	end
	local res = GetSpellPowerCost(arg);
	if (not res) then return end
	--print("# value is", type(res));
	for x, item in pairs(res) do
		if (item.name == "MANA") then
			if (item.cost) then
				local pm = UnitPower("player", 0);
				return math.floor(pm / item.cost), "MANA";
			end
		end
	end
end



_.round = function(number, digits)
	local pow;
	if (digits and digits > 0) then
		pow = 10 ^ digits;
		number = number * pow;
	end
	number = number % 1 >= 0.5 and math.ceil(number) or math.floor(number);
	if (pow) then
		number = number / pow;
	end
	return number;
end

_.getCooldown = function(_type, id)

	if (id and (_type == "spell" or _type == "Spell")) then
		return GetSpellCooldown(id);
	end

	if (id and type(id) == "number" and (_type == "item" or _type == "Item")) then
		return GetItemCooldown(id);
	end

end

_.isValue = function (arg)
	return arg ~= nil and arg ~= "";
end


local A = Tabu:Addon(...);
local _ = A.utils;

A.Bus = {
	Frame = CreateFrame("Frame", nil, UIParent);
	events = {},
	On = function (event, cb)
	
		if (type(cb) ~= "function") then 
			_.print("BUS: Prodived callback not a function");
			return;
		end;
	
		local handlers = A.Bus.events[event];
		if (handlers == nil) then
			A.Bus.Frame:RegisterEvent(event);
			handlers = {};
			A.Bus.events[event] = handlers;
		end
	
		table.insert(handlers, cb);
		
	end
};

local function OnGlobalEvent(self, event, ...) 
	local handlers = A.Bus.events[event];

	if (type(handlers) ~= "table") then return end;

	for _, callback in pairs(handlers) do
		if (type(callback) == "function") then
			callback(...);
		end
	end
end


A.Bus.Frame:SetScript("OnEvent", OnGlobalEvent);

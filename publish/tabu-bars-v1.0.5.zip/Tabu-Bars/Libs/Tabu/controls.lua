--controls

Tabu.Controls = {}

local C = Tabu.Controls;

C.mixin = function(frame, context)
	-- local ccontrol = context.edit
	-- frame.control = childControl;
	-- frame.setControlValue = function(self, ...)
		
	-- end
	-- frame.getControlValue = function(self)
	-- 	local value = edit.control:GetNumber();
	-- 	if (not value) then
	-- 		return nil;
	-- 	end
	-- 	return value;
	-- end	
end

C.GetColorPickerValue = function()
	if (not ColorPickerFrame:IsShown()) then return end;
	local r, g, b = ColorPickerFrame:GetColorRGB();
	local a = OpacitySliderFrame:GetValue();
	return r, g, b, a
end


C.ShowColorPicker = function(changeCb, r, g, b, a)
	local cb = function()
		changeCb(C.GetColorPickerValue())
	end
	ColorPickerFrame:SetColorRGB(r,g,b);
	ColorPickerFrame.hasOpacity, ColorPickerFrame.opacity = (a ~= nil), a;
	ColorPickerFrame.previousValues = { r , g, b, a };
	ColorPickerFrame.func, ColorPickerFrame.opacityFunc = cb, cb;
	ColorPickerFrame.cancelFunc = function()
		changeCb(unpack(ColorPickerFrame.previousValues));
	end
	ColorPickerFrame:Hide(); -- Need to run the OnShow handler.
	ColorPickerFrame:Show();	
end

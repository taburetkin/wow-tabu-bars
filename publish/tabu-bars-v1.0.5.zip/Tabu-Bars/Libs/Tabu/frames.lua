local A = Tabu:Addon(...);
local _ = A.utils;

_.createColorTexture = function(frame, r, g, b, a, layer, inherits, sublayer)
	local t = frame:CreateTexture(nil, layer, inherits, sublayer);
	t:SetAllPoints();
	t:SetColorTexture(r, g, b, a);
	return t;
end

_.setFrameBorder = function (frame, r, g, b, a, size, outer)
	size = size or 1;
	local insets;
	if (outer) then
		insets = { left = -size, right = -size, top = -size, bottom = -size }
	end
	if (r ~= nil) then
		frame:SetBackdrop({
			edgeFile = [[Interface\Buttons\WHITE8x8]],
			edgeSize = size,
			insets = insets
		});
		frame:SetBackdropBorderColor(r,g,b,a);
	else
		frame:SetBackdrop(nil);		
	end
end

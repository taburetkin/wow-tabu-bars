local A = Tabu:Addon(...);
local _ = A.utils;


_.arrayHasAny = function (where, what)
	for _, v1 in pairs(where) do
		for _, v2 in pairs(what) do
			if (v1 == v2) then return true end
		end
	end
	return false;
end

_.arrayHasValue = function(tbl, value)
	for i, v in pairs(tbl) do
		if (v == value) then return true end
	end
	return false;
end

_.arrayIndexOf = function(tbl, value)
	for index, v in ipairs(tbl) do
		if (v == value) then return index end
	end	
end

_.findFirst = function(tbl, compare)
	for index, v in pairs(tbl) do
		if (compare(v, index)) then
			return v, index
		end
	end
end
